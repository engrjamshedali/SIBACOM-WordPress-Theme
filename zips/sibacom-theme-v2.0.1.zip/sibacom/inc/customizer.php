<?php
/**
 * SIBACOM Theme Customizer
 *
 * @package SIBACOM
 */

if (!defined('ABSPATH')) {
    exit;
}

function sibacom_customize_register($wp_customize) {
    // SIBACOM Branding & Colors Section
    $wp_customize->add_section('sibacom_colors_section', array(
        'title'       => esc_html__('SIBACOM Design & Colors', 'sibacom'),
        'priority'    => 30,
        'description' => esc_html__('Configure global colors for SIBACOM Neumorphic UI design system.', 'sibacom'),
    ));

    // Primary Royal Blue
    $wp_customize->add_setting('sibacom_primary_color', array(
        'default'           => '#173F91',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sibacom_primary_color', array(
        'label'    => esc_html__('Primary Royal Blue', 'sibacom'),
        'section'  => 'sibacom_colors_section',
        'settings' => 'sibacom_primary_color',
    )));

    // Deep Navy
    $wp_customize->add_setting('sibacom_navy_color', array(
        'default'           => '#102E68',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sibacom_navy_color', array(
        'label'    => esc_html__('Deep Navy', 'sibacom'),
        'section'  => 'sibacom_colors_section',
        'settings' => 'sibacom_navy_color',
    )));

    // Technology Green
    $wp_customize->add_setting('sibacom_techgreen_color', array(
        'default'           => '#079B58',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sibacom_techgreen_color', array(
        'label'    => esc_html__('Technology Green', 'sibacom'),
        'section'  => 'sibacom_colors_section',
        'settings' => 'sibacom_techgreen_color',
    )));

    // Background Color
    $wp_customize->add_setting('sibacom_bg_color', array(
        'default'           => '#F4F6FA',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sibacom_bg_color', array(
        'label'    => esc_html__('Background Soft Surface', 'sibacom'),
        'section'  => 'sibacom_colors_section',
        'settings' => 'sibacom_bg_color',
    )));

    // Section: Electrical Circuits & Signal Animations
    $wp_customize->add_section('sibacom_circuits_section', array(
        'title'       => esc_html__('SIBACOM Circuit & Signal Effects', 'sibacom'),
        'priority'    => 35,
        'description' => esc_html__('Configure animated electrical circuits, PCB traces, and signal flow pulses.', 'sibacom'),
    ));

    // Circuit Pulse Color
    $wp_customize->add_setting('sibacom_circuit_pulse_color', array(
        'default'           => '#079B58',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'sibacom_circuit_pulse_color', array(
        'label'    => esc_html__('Signal Pulse Color', 'sibacom'),
        'section'  => 'sibacom_circuits_section',
        'settings' => 'sibacom_circuit_pulse_color',
    )));

    // Circuit Pulse Animation Speed
    $wp_customize->add_setting('sibacom_circuit_speed', array(
        'default'           => '4s',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('sibacom_circuit_speed', array(
        'label'       => esc_html__('Pulse Animation Base Speed (e.g. 4s)', 'sibacom'),
        'section'     => 'sibacom_circuits_section',
        'type'        => 'text',
    ));
}
add_action('customize_register', 'sibacom_customize_register');

/**
 * Output dynamic CSS variables for customizer overrides
 */
function sibacom_customizer_css() {
    $primary       = get_theme_mod('sibacom_primary_color', '#173F91');
    $navy          = get_theme_mod('sibacom_navy_color', '#102E68');
    $techgreen     = get_theme_mod('sibacom_techgreen_color', '#079B58');
    $bg            = get_theme_mod('sibacom_bg_color', '#F4F6FA');
    $pulse_color   = get_theme_mod('sibacom_circuit_pulse_color', '#079B58');
    $circuit_speed = get_theme_mod('sibacom_circuit_speed', '4s');

    $custom_css = "
        :root {
            --sibacom-primary: {$primary};
            --sibacom-navy: {$navy};
            --sibacom-techgreen: {$techgreen};
            --sibacom-bg: {$bg};
            --sibacom-circuit-pulse-color: {$pulse_color};
            --sibacom-circuit-speed: {$circuit_speed};
        }
    ";
    wp_add_inline_style('sibacom-style', $custom_css);
}
add_action('wp_enqueue_scripts', 'sibacom_customizer_css', 20);

