<?php
/**
 * SIBACOM Template Tags & Helper Functions
 *
 * Official Dual-Society Organizational Branding & Academic Partnership Integration
 * - Overarching Institutional Identity: Sukkur IBA University
 * - Joint Primary Organizers: CSE Society & EE Society
 * - Supporting Academic Partners: Department of CSE & Department of EE
 *
 * @package SIBACOM
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get Option Helper with Fallback
 */
function sibacom_get_option($key, $default = '') {
    $val = get_option('sibacom_' . $key, '');
    if ($val === '' || $val === false) {
        return $default;
    }
    return $val;
}

/**
 * Display Official University Logo (Overarching Institutional Identity)
 */
function sibacom_the_university_logo($mode = 'default') {
    if ($mode === 'white') {
        $custom_white = sibacom_get_option('university_logo_white_url');
        if (!empty($custom_white)) {
            echo '<img src="' . esc_url($custom_white) . '" alt="' . esc_attr__('Sukkur IBA University – Overarching Institutional Identity', 'sibacom') . '" class="uni-logo uni-logo-white" width="150" height="44" decoding="async" style="height:44px; width:auto; max-width:150px; object-fit:contain;" />';
            return;
        }
        $default_logo = SIBACOM_THEME_URI . '/assets/images/sukkur_iba_white_logo.png';
        echo '<img src="' . esc_url($default_logo) . '" alt="' . esc_attr__('Sukkur IBA University – Overarching Institutional Identity', 'sibacom') . '" class="uni-logo uni-logo-white" width="150" height="44" decoding="async" style="height:44px; width:auto; max-width:150px; object-fit:contain;" />';
        return;
    }

    $custom_logo = sibacom_get_option('university_logo_url');
    if (!empty($custom_logo)) {
        echo '<img src="' . esc_url($custom_logo) . '" alt="' . esc_attr__('Sukkur IBA University – Overarching Institutional Identity', 'sibacom') . '" class="uni-logo" width="150" height="44" fetchpriority="high" decoding="async" style="height:44px; width:auto; max-width:150px; object-fit:contain;" />';
    } else {
        $default_logo = SIBACOM_THEME_URI . '/assets/images/sukkur_iba_logo.png';
        echo '<img src="' . esc_url($default_logo) . '" alt="' . esc_attr__('Sukkur IBA University – Overarching Institutional Identity', 'sibacom') . '" class="uni-logo" width="150" height="44" fetchpriority="high" decoding="async" style="height:44px; width:auto; max-width:150px; object-fit:contain;" />';
    }
}

/**
 * Display Official CSE Society Logo (Joint Primary Organizer)
 */
function sibacom_the_cse_society_logo($mode = 'color', $class = 'society-logo cse-society-logo', $height = 42, $max_width = 160) {
    $custom_logo = sibacom_get_option('cse_society_logo_url');
    if (empty($custom_logo)) {
        $custom_logo = sibacom_get_option('society_logo_url');
    }

    $h = is_numeric($height) ? $height . 'px' : esc_attr($height);
    $w = is_numeric($max_width) ? $max_width . 'px' : esc_attr($max_width);
    $num_h = is_numeric($height) ? intval($height) : 42;
    $num_w = is_numeric($max_width) ? intval($max_width) : 160;

    if ($mode === 'white') {
        $white_logo = SIBACOM_THEME_URI . '/assets/images/cse_society_logo_white.png';
        if (!file_exists(SIBACOM_THEME_DIR . '/assets/images/cse_society_logo_white.png')) {
            $white_logo = SIBACOM_THEME_URI . '/assets/images/cse_society_logo_transparent.png';
        }
        echo '<img src="' . esc_url($white_logo) . '" alt="' . esc_attr__('Computer Systems Engineering Society (CSE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . ' society-logo-white" width="' . $num_w . '" height="' . $num_h . '" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain; display:inline-block;" />';
        return;
    }

    if (!empty($custom_logo)) {
        echo '<img src="' . esc_url($custom_logo) . '" alt="' . esc_attr__('Computer Systems Engineering Society (CSE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . '" width="' . $num_w . '" height="' . $num_h . '" fetchpriority="high" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    } else {
        $default_logo = SIBACOM_THEME_URI . '/assets/images/cse_society_logo_transparent.png';
        if (!file_exists(SIBACOM_THEME_DIR . '/assets/images/cse_society_logo_transparent.png')) {
            $default_logo = SIBACOM_THEME_URI . '/assets/images/cse_society_logo.png';
        }
        echo '<img src="' . esc_url($default_logo) . '" alt="' . esc_attr__('Computer Systems Engineering Society (CSE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . '" width="' . $num_w . '" height="' . $num_h . '" fetchpriority="high" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    }
}

/**
 * Display Official EE Society Logo (Joint Primary Organizer)
 * Equal prominence, exact display dimensions and aspect ratio handling
 */
function sibacom_the_ee_society_logo($mode = 'color', $class = 'society-logo ee-society-logo', $height = 42, $max_width = 160) {
    $custom_logo = sibacom_get_option('ee_society_logo_url');
    $h = is_numeric($height) ? $height . 'px' : esc_attr($height);
    $w = is_numeric($max_width) ? $max_width . 'px' : esc_attr($max_width);
    $num_h = is_numeric($height) ? intval($height) : 42;
    $num_w = is_numeric($max_width) ? intval($max_width) : 160;

    if ($mode === 'white') {
        $white_logo = SIBACOM_THEME_URI . '/assets/images/ee_society_logo_white.png';
        if (!file_exists(SIBACOM_THEME_DIR . '/assets/images/ee_society_logo_white.png')) {
            $white_logo = SIBACOM_THEME_URI . '/assets/images/ee_society_logo_transparent.png';
        }
        if (!file_exists(SIBACOM_THEME_DIR . '/assets/images/ee_society_logo_transparent.png') && !file_exists(SIBACOM_THEME_DIR . '/assets/images/ee_society_logo_white.png')) {
            $white_logo = !empty($custom_logo) ? $custom_logo : SIBACOM_THEME_URI . '/assets/images/ee_society_logo.png';
        }
        echo '<img src="' . esc_url($white_logo) . '" alt="' . esc_attr__('Electrical Engineering Society (EE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . ' society-logo-white" width="' . $num_w . '" height="' . $num_h . '" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain; display:inline-block;" />';
        return;
    }

    if (!empty($custom_logo)) {
        echo '<img src="' . esc_url($custom_logo) . '" alt="' . esc_attr__('Electrical Engineering Society (EE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . '" width="' . $num_w . '" height="' . $num_h . '" fetchpriority="high" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
        return;
    }

    // Bundled candidates in priority order (transparent PNG preferred)
    $bundled_candidates = array(
        'ee_society_logo_transparent.png',
        'ee_society_logo.png',
        'ee_society_logo.jpg',
        'ee_society_logo.svg'
    );
    $found_file = '';
    foreach ($bundled_candidates as $cand) {
        if (file_exists(SIBACOM_THEME_DIR . '/assets/images/' . $cand)) {
            $found_file = SIBACOM_THEME_URI . '/assets/images/' . $cand;
            break;
        }
    }

    if (!empty($found_file)) {
        echo '<img src="' . esc_url($found_file) . '" alt="' . esc_attr__('Electrical Engineering Society (EE Society) – Sukkur IBA University', 'sibacom') . '" class="' . esc_attr($class) . '" width="' . $num_w . '" height="' . $num_h . '" fetchpriority="high" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    } else {
        // Formal typographic insignia card ensuring equal prominence without inventing a missing logo
        $is_white = ($mode === 'white');
        $bg_style = $is_white ? 'background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.22); color:#FFFFFF;' : 'background:#FFFFFF; border:1px solid #CBD5E1; color:#173F91; box-shadow:0 2px 6px rgba(0,0,0,0.04);';
        echo '<div class="' . esc_attr($class) . ' ee-society-insignia" style="height:' . $h . '; max-height:' . $h . '; width:auto; min-width:130px; max-width:' . $w . '; display:inline-flex; align-items:center; justify-content:center; gap:8px; padding:0 12px; border-radius:6px; ' . $bg_style . ' font-family:var(--font-heading, sans-serif); font-weight:700; font-size:13px; letter-spacing:0.02em; white-space:nowrap; text-align:center;">';
        echo '<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--sibacom-techgreen, #079B58);"></span>';
        echo '<span>' . esc_html__('EE Society', 'sibacom') . '</span>';
        echo '</div>';
    }
}

/**
 * Backward Compatible: Display Primary Society Logo
 */
function sibacom_the_society_logo($class = 'society-logo', $height = 42, $max_width = 160) {
    sibacom_the_cse_society_logo('color', $class, $height, $max_width);
}

/**
 * Backward Compatible: Display White Society Logo
 */
function sibacom_the_society_logo_white($class = 'society-logo society-logo-white', $height = 42, $max_width = 160) {
    sibacom_the_cse_society_logo('white', $class, $height, $max_width);
}

/**
 * Display Department of CSE Logo (Supporting Academic Partner)
 */
function sibacom_the_cse_dept_logo($height = 55, $max_width = 160) {
    $custom_logo = sibacom_get_option('cse_dept_logo_url');
    if (empty($custom_logo)) {
        $custom_logo = sibacom_get_option('dept_logo_url');
    }
    $h = is_numeric($height) ? $height . 'px' : esc_attr($height);
    $w = is_numeric($max_width) ? $max_width . 'px' : esc_attr($max_width);

    if (!empty($custom_logo)) {
        echo '<img src="' . esc_url($custom_logo) . '" alt="' . esc_attr__('Department of Computer Systems Engineering – Sukkur IBA University', 'sibacom') . '" class="dept-logo cse-dept-logo" width="160" height="' . intval($height) . '" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    } else {
        $default_logo = SIBACOM_THEME_URI . '/assets/images/cse_dept_logo.jpg';
        echo '<img src="' . esc_url($default_logo) . '" alt="' . esc_attr__('Department of Computer Systems Engineering – Sukkur IBA University', 'sibacom') . '" class="dept-logo cse-dept-logo" width="160" height="' . intval($height) . '" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    }
}

/**
 * Display Department of EE Logo (Supporting Academic Partner)
 */
function sibacom_the_ee_dept_logo($height = 55, $max_width = 160) {
    $custom_logo = sibacom_get_option('ee_dept_logo_url');
    $h = is_numeric($height) ? $height . 'px' : esc_attr($height);
    $w = is_numeric($max_width) ? $max_width . 'px' : esc_attr($max_width);
    $num_h = is_numeric($height) ? intval($height) : 55;
    $num_w = is_numeric($max_width) ? intval($max_width) : 160;

    $bundled_candidates = array(
        'ee_dept_logo.jpg',
        'ee_dept_logo.png',
        'ee_dept_logo.svg'
    );
    $found_file = '';
    foreach ($bundled_candidates as $cand) {
        if (file_exists(SIBACOM_THEME_DIR . '/assets/images/' . $cand)) {
            $found_file = SIBACOM_THEME_URI . '/assets/images/' . $cand;
            break;
        }
    }

    $logo_src = !empty($custom_logo) ? $custom_logo : $found_file;

    if (!empty($logo_src)) {
        echo '<img src="' . esc_url($logo_src) . '" alt="' . esc_attr__('Department of Electrical Engineering – Sukkur IBA University', 'sibacom') . '" class="dept-logo ee-dept-logo" width="' . $num_w . '" height="' . $num_h . '" decoding="async" style="height:' . $h . '; max-height:' . $h . '; width:auto; max-width:' . $w . '; object-fit:contain;" />';
    } else {
        echo '<div class="dept-logo ee-dept-insignia" style="height:' . $h . '; max-height:' . $h . '; width:auto; min-width:130px; max-width:' . $w . '; display:inline-flex; align-items:center; justify-content:center; gap:8px; padding:0 12px; background:#F8FAFC; border:1px solid #CBD5E1; border-radius:6px; color:#102E68; font-family:var(--font-heading, sans-serif); font-weight:700; font-size:12px; letter-spacing:0.02em; white-space:nowrap; text-align:center;">';
        echo '<i class="fa-solid fa-bolt" style="color:var(--sibacom-techgreen, #079B58);"></i>';
        echo '<span>' . esc_html__('Dept. of EE', 'sibacom') . '</span>';
        echo '</div>';
    }
}

/**
 * Backward Compatible: Display Dept Logo (CSE)
 */
function sibacom_the_dept_logo() {
    sibacom_the_cse_dept_logo(55, 160);
}

/**
 * Display SISC Student Council Logo
 */
function sibacom_the_sisc_logo() {
    $custom_logo = sibacom_get_option('sisc_logo_url');
    if (!empty($custom_logo)) {
        echo '<img src="' . esc_url($custom_logo) . '" alt="' . esc_attr__('SISC – Sukkur IBA Student Council', 'sibacom') . '" class="sisc-logo" width="160" height="55" decoding="async" style="height:55px; width:auto; object-fit:contain;" />';
    } else {
        $default_logo = SIBACOM_THEME_URI . '/assets/images/sisc_logo.jpg';
        echo '<img src="' . esc_url($default_logo) . '" alt="' . esc_attr__('SISC – Sukkur IBA Student Council', 'sibacom') . '" class="sisc-logo" width="160" height="55" decoding="async" style="height:55px; width:auto; object-fit:contain;" />';
    }
}

/**
 * Get Background Campus Photo (Optimized with WebP priority)
 */
function sibacom_get_campus_bg_url() {
    $custom_bg = sibacom_get_option('hero_bg_image_url');
    if (!empty($custom_bg)) {
        return $custom_bg;
    }
    // Prefer WebP for faster above-the-fold delivery
    if (file_exists(SIBACOM_THEME_DIR . '/assets/images/academic_block3_clean_v2.webp')) {
        return SIBACOM_THEME_URI . '/assets/images/academic_block3_clean_v2.webp';
    }
    return SIBACOM_THEME_URI . '/assets/images/academic_block3_clean_v2.jpg';
}

/**
 * Determine if a specific navigation item is active
 *
 * @param string $slug Page slug or template identifier (e.g. 'home', 'about', 'events', etc.)
 * @return bool True if active, false otherwise.
 */
function sibacom_is_nav_active($slug) {
    if ($slug === 'home' || $slug === '' || $slug === '/') {
        return (is_front_page() || is_home());
    }

    if (function_exists('is_page') && is_page($slug)) {
        return true;
    }

    if (function_exists('is_page_template')) {
        if (is_page_template('templates/template-' . $slug . '.php')) {
            return true;
        }
        if ($slug === 'events' && (is_page_template('templates/template-events.php') || is_page_template('templates/template-competitions.php'))) {
            return true;
        }
    }

    if (isset($GLOBALS['sibacom_current_page']) && $GLOBALS['sibacom_current_page'] === $slug) {
        return true;
    }

    return false;
}

/**
 * ==========================================================================
 * SIBACOM Electrical Circuits, PCB Traces & Signal Flow Template Tags
 * ==========================================================================
 */

/**
 * Output Hero Section Animated Circuits (Left & Right Flanks + Digital Bus)
 */
function sibacom_the_hero_circuits() {
    ?>
    <div class="sibacom-hero-circuit-overlay" aria-hidden="true">
        <!-- Left Flank Circuit Pathways (MCU / Logic Ingest) -->
        <div class="sibacom-hero-circuit-left">
            <svg viewBox="0 0 340 700" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMinYMid meet">
                <!-- Base Tracks (PCB Copper / Royal Blue Traces) -->
                <path d="M 0 90 L 130 90 L 170 130 L 170 240 L 210 280 L 210 390 L 170 430 L 110 430" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <path d="M 0 170 L 80 170 L 120 210 L 120 350 L 160 390 L 160 530 L 100 590 L 40 590" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <path d="M 0 310 L 60 310 L 90 340 L 90 470 L 140 520 L 210 520" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.2" stroke-dasharray="3 3" />
                
                <!-- Animated Signal Pulses (Travelling Energy Packets) -->
                <path d="M 0 90 L 130 90 L 170 130 L 170 240 L 210 280 L 210 390 L 170 430 L 110 430" class="sibacom-signal-pulse speed-normal" stroke-width="2.5" />
                <path d="M 0 170 L 80 170 L 120 210 L 120 350 L 160 390 L 160 530 L 100 590 L 40 590" class="sibacom-signal-pulse speed-fast delay-2" stroke-width="2.5" />
                <path d="M 0 310 L 60 310 L 90 340 L 90 470 L 140 520 L 210 520" class="sibacom-signal-pulse speed-slow delay-1" stroke-width="2" />

                <!-- Microchip Package Footprint (IC1 - MCU CORE) -->
                <rect x="25" y="225" width="45" height="50" rx="4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.5" fill="#FFFFFF" fill-opacity="0.9" />
                <circle cx="35" cy="235" r="2.5" fill="var(--sibacom-circuit-blue)" />
                <text x="32" y="255" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" letter-spacing="0.5">MCU</text>
                <text x="32" y="264" font-family="monospace" font-size="6" font-weight="600" fill="var(--sibacom-circuit-techgreen)">32b</text>

                <!-- IC Pins (Right side) -->
                <line x1="70" y1="235" x2="85" y2="235" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="70" y1="245" x2="90" y2="245" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="70" y1="255" x2="85" y2="255" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="70" y1="265" x2="90" y2="265" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />

                <!-- Terminal Vias & Illuminating Connection Nodes -->
                <circle cx="110" cy="430" r="5" class="sibacom-solder-pad" />
                <circle cx="110" cy="430" r="2.5" class="sibacom-circuit-node node-pulse-1" fill="var(--sibacom-circuit-techgreen)" />
                <text x="120" y="433" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" opacity="0.6">TP1_CLK</text>

                <circle cx="40" cy="590" r="5" class="sibacom-solder-pad" />
                <circle cx="40" cy="590" r="2.5" class="sibacom-circuit-node node-pulse-2" fill="var(--sibacom-circuit-techgreen)" />
                <text x="50" y="593" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" opacity="0.6">BUS_RX</text>

                <circle cx="210" cy="520" r="4" class="sibacom-solder-pad" />
                <circle cx="210" cy="520" r="2" class="sibacom-circuit-node node-pulse-4" fill="var(--sibacom-circuit-blue)" />

                <!-- Branching Test Points -->
                <circle cx="170" cy="130" r="3" fill="var(--sibacom-circuit-blue)" opacity="0.5" />
                <circle cx="210" cy="280" r="3" fill="var(--sibacom-circuit-techgreen)" opacity="0.7" />
                <circle cx="160" cy="390" r="3" fill="var(--sibacom-circuit-blue)" opacity="0.5" />
            </svg>
        </div>

        <!-- Right Flank Circuit Pathways (DSP / Bus Output) -->
        <div class="sibacom-hero-circuit-right">
            <svg viewBox="0 0 340 700" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMaxYMid meet">
                <!-- Base Tracks -->
                <path d="M 340 100 L 210 100 L 170 140 L 170 250 L 130 290 L 130 400 L 170 440 L 230 440" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <path d="M 340 190 L 250 190 L 210 230 L 210 370 L 170 410 L 170 550 L 230 610 L 290 610" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <path d="M 340 330 L 270 330 L 240 360 L 240 480 L 190 530 L 120 530" class="sibacom-signal-track" stroke="var(--sibacom-circuit-trace)" stroke-width="1.2" stroke-dasharray="3 3" />

                <!-- Animated Signal Pulses -->
                <path d="M 340 100 L 210 100 L 170 140 L 170 250 L 130 290 L 130 400 L 170 440 L 230 440" class="sibacom-signal-pulse speed-slow delay-3" stroke-width="2.5" />
                <path d="M 340 190 L 250 190 L 210 230 L 210 370 L 170 410 L 170 550 L 230 610 L 290 610" class="sibacom-signal-pulse speed-normal delay-1" stroke-width="2.5" />
                <path d="M 340 330 L 270 330 L 240 360 L 240 480 L 190 530 L 120 530" class="sibacom-signal-pulse speed-fast delay-4" stroke-width="2" />

                <!-- FPGA Package Footprint -->
                <rect x="270" y="240" width="45" height="48" rx="4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.5" fill="#FFFFFF" fill-opacity="0.9" />
                <circle cx="305" cy="250" r="2.5" fill="var(--sibacom-circuit-techgreen)" />
                <text x="278" y="268" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" letter-spacing="0.5">DSP</text>
                <text x="278" y="277" font-family="monospace" font-size="6" font-weight="600" fill="var(--sibacom-circuit-techgreen)">CORE</text>

                <!-- IC Pins (Left side) -->
                <line x1="270" y1="248" x2="255" y2="248" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="270" y1="258" x2="250" y2="258" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="270" y1="268" x2="255" y2="268" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
                <line x1="270" y1="278" x2="250" y2="278" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />

                <!-- Terminal Vias & Illuminating Connection Nodes -->
                <circle cx="230" cy="440" r="5" class="sibacom-solder-pad" />
                <circle cx="230" cy="440" r="2.5" class="sibacom-circuit-node node-pulse-3" fill="var(--sibacom-circuit-techgreen)" />
                <text x="175" y="443" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" opacity="0.6">BUS_TX</text>

                <circle cx="290" cy="610" r="5" class="sibacom-solder-pad" />
                <circle cx="290" cy="610" r="2.5" class="sibacom-circuit-node node-pulse-1" fill="var(--sibacom-circuit-techgreen)" />
                <text x="245" y="613" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" opacity="0.6">TP2_DATA</text>

                <circle cx="120" cy="530" r="4" class="sibacom-solder-pad" />
                <circle cx="120" cy="530" r="2" class="sibacom-circuit-node node-pulse-2" fill="var(--sibacom-circuit-blue)" />

                <!-- Branching Test Points -->
                <circle cx="170" cy="140" r="3" fill="var(--sibacom-circuit-techgreen)" opacity="0.7" />
                <circle cx="130" cy="290" r="3" fill="var(--sibacom-circuit-blue)" opacity="0.5" />
                <circle cx="170" cy="410" r="3" fill="var(--sibacom-circuit-techgreen)" opacity="0.6" />
            </svg>
        </div>

        <!-- Bottom Digital Data Bus (Linking Hero to Event Info Section) -->
        <div class="sibacom-hero-bus-bottom">
            <svg viewBox="0 0 1200 36" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
                <line x1="0" y1="12" x2="1200" y2="12" stroke="var(--sibacom-circuit-trace)" stroke-width="1.2" />
                <line x1="0" y1="20" x2="1200" y2="20" stroke="var(--sibacom-circuit-trace)" stroke-width="1.2" stroke-dasharray="4 8" />
                <line x1="0" y1="28" x2="1200" y2="28" stroke="var(--sibacom-circuit-trace)" stroke-width="1" />

                <!-- Bus Signal Pulses -->
                <path d="M 0 12 L 1200 12" class="sibacom-signal-pulse speed-fast delay-1" stroke-width="2" />
                <path d="M 1200 28 L 0 28" class="sibacom-signal-pulse speed-normal delay-3 reverse" stroke-width="1.8" />

                <!-- Bus Tap Nodes -->
                <circle cx="200" cy="12" r="3" fill="var(--sibacom-circuit-techgreen)" />
                <circle cx="450" cy="20" r="2.5" fill="var(--sibacom-circuit-blue)" />
                <circle cx="750" cy="12" r="3" fill="var(--sibacom-circuit-techgreen)" />
                <circle cx="1000" cy="28" r="2.5" fill="var(--sibacom-circuit-blue)" />
            </svg>
        </div>
    </div>
    <?php
}

/**
 * Output PCB Corner Bracket SVG
 *
 * @param string $pos Corner position: 'tl', 'tr', 'bl', 'br'
 */
function sibacom_the_circuit_corner($pos = 'tl') {
    $pos = in_array($pos, array('tl', 'tr', 'bl', 'br')) ? $pos : 'tl';
    ?>
    <div class="sibacom-circuit-corner corner-<?php echo esc_attr($pos); ?>" aria-hidden="true">
        <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <?php if ($pos === 'tl') : ?>
                <path d="M 2 26 L 2 12 L 12 2 L 26 2" class="corner-line" />
                <circle cx="26" cy="2" r="2" class="corner-via" />
                <circle cx="2" cy="26" r="2" class="corner-via" />
            <?php elseif ($pos === 'tr') : ?>
                <path d="M 46 26 L 46 12 L 36 2 L 22 2" class="corner-line" />
                <circle cx="22" cy="2" r="2" class="corner-via" />
                <circle cx="46" cy="26" r="2" class="corner-via" />
            <?php elseif ($pos === 'bl') : ?>
                <path d="M 2 22 L 2 36 L 12 46 L 26 46" class="corner-line" />
                <circle cx="26" cy="46" r="2" class="corner-via" />
                <circle cx="2" cy="22" r="2" class="corner-via" />
            <?php elseif ($pos === 'br') : ?>
                <path d="M 46 22 L 46 36 L 36 46 L 22 46" class="corner-line" />
                <circle cx="22" cy="46" r="2" class="corner-via" />
                <circle cx="46" cy="22" r="2" class="corner-via" />
            <?php endif; ?>
        </svg>
    </div>
    <?php
}

/**
 * Output Circuit Connector Separator between Joint Organizers & Academic Partners
 */
function sibacom_the_circuit_connector() {
    ?>
    <div class="sibacom-circuit-connector" aria-hidden="true">
        <svg viewBox="0 0 680 48" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid meet">
            <!-- Left Wing (CSE Society Bridge) -->
            <path d="M 40 24 L 200 24 L 230 14 L 300 14" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
            <path d="M 80 34 L 180 34 L 210 24 L 290 24" stroke="var(--sibacom-circuit-trace)" stroke-width="1" stroke-dasharray="3 3" />
            <path d="M 40 24 L 200 24 L 230 14 L 300 14" class="sibacom-signal-pulse speed-normal" stroke-width="2.2" />

            <!-- Left Terminal Via -->
            <circle cx="40" cy="24" r="4.5" class="sibacom-solder-pad" />
            <circle cx="40" cy="24" r="2" fill="var(--sibacom-circuit-blue)" />
            <text x="52" y="20" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" opacity="0.7">CSE_BUS</text>

            <!-- Center Microprocessor Interconnect Chip -->
            <g transform="translate(300, 4)">
                <rect x="0" y="0" width="80" height="40" rx="4" class="sibacom-connector-chip" />
                <rect x="6" y="6" width="68" height="28" rx="2" fill="var(--sibacom-bg)" />
                <circle cx="16" cy="15" r="2" class="sibacom-connector-chip-core" />
                <circle cx="16" cy="25" r="2" class="sibacom-connector-chip-core" />
                <text x="24" y="18" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-blue)" letter-spacing="0.5">SIBACOM</text>
                <text x="24" y="27" font-family="monospace" font-size="6" font-weight="600" fill="var(--sibacom-circuit-techgreen)">BRIDGE</text>

                <!-- Top & Bottom Micro-pins -->
                <line x1="20" y1="0" x2="20" y2="-4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="32" y1="0" x2="32" y2="-4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="44" y1="0" x2="44" y2="-4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="56" y1="0" x2="56" y2="-4" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />

                <line x1="20" y1="40" x2="20" y2="44" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="32" y1="40" x2="32" y2="44" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="44" y1="40" x2="44" y2="44" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
                <line x1="56" y1="40" x2="56" y2="44" stroke="var(--sibacom-circuit-blue)" stroke-width="1.2" />
            </g>

            <!-- Right Wing (EE Society Bridge) -->
            <path d="M 380 14 L 450 14 L 480 24 L 640 24" stroke="var(--sibacom-circuit-trace)" stroke-width="1.5" />
            <path d="M 390 24 L 470 24 L 500 34 L 600 34" stroke="var(--sibacom-circuit-trace)" stroke-width="1" stroke-dasharray="3 3" />
            <path d="M 380 14 L 450 14 L 480 24 L 640 24" class="sibacom-signal-pulse speed-normal delay-2" stroke-width="2.2" />

            <!-- Right Terminal Via -->
            <circle cx="640" cy="24" r="4.5" class="sibacom-solder-pad" />
            <circle cx="640" cy="24" r="2" fill="var(--sibacom-circuit-techgreen)" />
            <text x="585" y="20" font-family="monospace" font-size="7" font-weight="700" fill="var(--sibacom-circuit-techgreen)" opacity="0.8">EE_BUS</text>
        </svg>
    </div>
    <?php
}

/**
 * Output Schedule Timeline Signal Pulse Track
 */
function sibacom_the_timeline_signal_track() {
    ?>
    <div class="sibacom-timeline-signal-pulse" aria-hidden="true"></div>
    <?php
}

/**
 * Output Footer Restrained PCB Background
 */
function sibacom_the_footer_circuits() {
    ?>
    <div class="sibacom-footer-circuit-bg" aria-hidden="true">
        <svg viewBox="0 0 1440 400" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
            <!-- Major Horizontal Buses -->
            <line x1="0" y1="60" x2="1440" y2="60" stroke="rgba(41, 98, 222, 0.22)" stroke-width="1.5" />
            <line x1="0" y1="72" x2="1440" y2="72" stroke="rgba(255, 255, 255, 0.08)" stroke-width="1" stroke-dasharray="6 8" />
            <line x1="0" y1="340" x2="1440" y2="340" stroke="rgba(41, 98, 222, 0.2)" stroke-width="1.2" />

            <!-- Flowing Signal Pulses across Footer Buses -->
            <path d="M 0 60 L 1440 60" class="sibacom-signal-pulse speed-slow" stroke="var(--sibacom-circuit-techgreen)" stroke-width="2" />
            <path d="M 1440 340 L 0 340" class="sibacom-signal-pulse speed-gentle delay-2 reverse" stroke="#2962DE" stroke-width="2" />

            <!-- Geometric Branching Traces -->
            <path d="M 180 60 L 180 180 L 240 240 L 240 340" stroke="rgba(41, 98, 222, 0.22)" stroke-width="1.5" />
            <path d="M 180 60 L 180 180 L 240 240 L 240 340" class="sibacom-signal-pulse speed-normal delay-1" stroke-width="2" />

            <path d="M 520 60 L 520 140 L 580 200 L 580 340" stroke="rgba(41, 98, 222, 0.18)" stroke-width="1.2" />
            <path d="M 880 340 L 880 220 L 820 160 L 820 60" stroke="rgba(41, 98, 222, 0.22)" stroke-width="1.5" />
            <path d="M 880 340 L 880 220 L 820 160 L 820 60" class="sibacom-signal-pulse speed-fast delay-3" stroke-width="2" />

            <path d="M 1240 60 L 1240 160 L 1180 220 L 1180 340" stroke="rgba(41, 98, 222, 0.18)" stroke-width="1.2" />

            <!-- Solder Pads & Glow Vias -->
            <circle cx="180" cy="180" r="3.5" fill="#2962DE" opacity="0.8" />
            <circle cx="240" cy="240" r="3.5" class="sibacom-circuit-node node-pulse-1" fill="var(--sibacom-circuit-techgreen)" />
            <circle cx="580" cy="200" r="3" fill="#2962DE" opacity="0.7" />
            <circle cx="820" cy="160" r="3.5" class="sibacom-circuit-node node-pulse-2" fill="var(--sibacom-circuit-techgreen)" />
            <circle cx="1180" cy="220" r="3" fill="#2962DE" opacity="0.7" />
        </svg>
    </div>
    <?php
}

/**
 * Output Reusable Subtle Circuit Background
 *
 * @param string $variant 'light' (default) or 'dark'
 * @param string $classes Extra CSS classes
 */
function sibacom_the_circuit_bg($variant = 'light', $classes = '') {
    $is_dark = ($variant === 'dark');
    $pattern_class = $is_dark ? 'sibacom-circuit-pattern-dark' : 'sibacom-circuit-pattern-light';
    ?>
    <div class="sibacom-circuit-background <?php echo esc_attr($pattern_class . ' ' . $classes); ?>" aria-hidden="true">
        <svg viewBox="0 0 1200 600" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
            <!-- Distributed Subtle PCB Traces -->
            <path d="M 50 40 L 180 40 L 220 80 L 220 180 L 260 220 L 400 220" class="trace-bus" />
            <path d="M 50 40 L 180 40 L 220 80 L 220 180 L 260 220 L 400 220" class="sibacom-signal-pulse speed-slow delay-2" stroke-width="1.8" />

            <path d="M 800 40 L 920 40 L 960 80 L 960 200 L 1020 260 L 1150 260" class="trace-bus" />
            <path d="M 800 40 L 920 40 L 960 80 L 960 200 L 1020 260 L 1150 260" class="sibacom-signal-pulse speed-gentle delay-1" stroke-width="1.8" />

            <path d="M 120 400 L 240 400 L 280 440 L 280 540 L 340 580" class="trace-thin" />
            <path d="M 720 540 L 840 540 L 880 500 L 880 380 L 940 320 L 1080 320" class="trace-bus" />
            <path d="M 720 540 L 840 540 L 880 500 L 880 380 L 940 320 L 1080 320" class="sibacom-signal-pulse speed-normal delay-3" stroke-width="1.8" />

            <!-- Circular Vias -->
            <circle cx="220" cy="80" r="3" class="circuit-via" />
            <circle cx="260" cy="220" r="3.5" class="circuit-via-green sibacom-circuit-node node-pulse-1" />
            <circle cx="960" cy="80" r="3" class="circuit-via" />
            <circle cx="1020" cy="260" r="3.5" class="circuit-via-green sibacom-circuit-node node-pulse-3" />
            <circle cx="880" cy="500" r="3" class="circuit-via" />
            <circle cx="940" cy="320" r="3.5" class="circuit-via-green sibacom-circuit-node node-pulse-2" />
        </svg>
    </div>
    <?php
}


