<?php
/**
 * SIBACOM 404 Template
 *
 * @package SIBACOM
 */

get_header();
?>
<div class="sibacom-section" style="min-height: 70vh; display: flex; align-items: center;">
    <div class="sibacom-container">
        <div class="neu-card text-center" style="max-width: 640px; margin: 0 auto; padding: 4rem 2rem;">
            <div class="sibacom-badge" style="margin-bottom: 1.5rem;">
                <i class="fa-solid fa-triangle-exclamation" style="color: #EAB308;"></i>
                <span><?php esc_html_e('404 Error', 'sibacom'); ?></span>
            </div>
            <h1 class="font-display" style="font-size: 5rem; line-height: 1; color: var(--sibacom-primary); margin-bottom: 1rem;">404</h1>
            <h2 class="font-display" style="font-size: 1.75rem; margin-bottom: 1rem;"><?php esc_html_e('Page Not Found', 'sibacom'); ?></h2>
            <p style="margin-bottom: 2rem; color: var(--sibacom-text-secondary);">
                <?php esc_html_e('The event page or resource you are looking for does not exist or has been relocated.', 'sibacom'); ?>
            </p>
            <a href="<?php echo esc_url(home_url('/')); ?>" class="sibacom-btn sibacom-btn-primary">
                <i class="fa-solid fa-house"></i>
                <span><?php esc_html_e('Back to SIBACOM Home', 'sibacom'); ?></span>
            </a>
        </div>
    </div>
</div>
<?php
get_footer();

