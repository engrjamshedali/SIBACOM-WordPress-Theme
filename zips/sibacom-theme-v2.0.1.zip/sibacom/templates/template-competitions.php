<?php
/**
 * Template Name: SIBACOM Competitions & Rewards Template
 *
 * Premium Dedicated Portal for SIBACOM 2026 Competitions, Fee Schedules & Cash Rewards
 * Sukkur IBA University • CSE Society & EE Society (SISC)
 * Single Source of Truth: Official SIBACOM 2026 Event Proposal
 *
 * @package SIBACOM
 */

get_header();

while (have_posts()) :
    the_post();

    // Check if built with Elementor
    if (function_exists('sibacom_is_built_with_elementor') && sibacom_is_built_with_elementor()) {
        the_content();
    } else {
        $reg_portal_url = get_option('sibacom_header_cta_url', 'https://iba-suk.edu.pk/sibacom/register');

// Centralized Official Competitions Data Source (Strictly Verified Proposal Records)
$official_competitions = array(
    array(
        'id'           => 'circuit-design',
        'number'       => '01',
        'title'        => 'Circuit Design Competition',
        'category'     => 'hardware',
        'category_lbl' => 'Hardware & Engineering',
        'track_code'   => 'A',
        'tagline'      => 'Three-stage electronic circuit design, breadboard prototyping & complex synthesis',
        'desc'         => 'Three stages: MCQ test, breadboard circuit design, and complex circuit design. Teams of two students. Top 10 advance to stage two, top five to the final, and top three are selected as winners.',
        'full_desc'    => 'The Circuit Design Competition is designed to cultivate creativity and technical innovation by challenging participants to design efficient, functional, and reliable electronic circuits. Working in groups of 2 students, teams progress through three rigorous stages: an eliminatory MCQ assessment, a hands-on breadboard circuit assembly task, and an advanced complex design challenge judged by senior engineering faculty.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Teams of 2 students',
        'min_team'     => 2,
        'max_team'     => 2,
        'format'       => '3-Stage Progressive Challenge',
        'rounds_count' => '3 Elimination Stages (MCQ -> Breadboard -> Complex)',
        'stages'       => array(
            array('num' => 1, 'name' => 'Stage 1: MCQs Test', 'desc' => 'Preliminary round featuring a set of MCQs to test theoretical electronics knowledge. Top 10 teams advance to stage two.'),
            array('num' => 2, 'name' => 'Stage 2: Breadboard Circuit Design', 'desc' => 'Hands-on circuit assembly on a breadboard. Moderately complex challenge evaluating practical skills, creativity, functionality, and efficiency. Top 5 teams advance to the final.'),
            array('num' => 3, 'name' => 'Stage 3: Complex Circuit Design Task', 'desc' => 'Ultimate challenge separating the best from the rest. The judges evaluate designs and select the top 3 teams as winners.')
        ),
        'rubric'       => array('Creativity and circuit architecture', 'Functionality under electrical test', 'Component efficiency & breadboard neatness', 'Practical circuit design and troubleshooting skills'),
        'venue'        => 'Academic Block-III Labs (Awaiting Final Allocation)',
        'venue_conf'   => false,
        'prizes'       => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000),
        'workshop'     => null,
        'objectives'   => array('Develop creativity and innovation by challenging participants to design efficient and functional electronic circuits.', 'Enhance problem-solving skills and technical expertise in electronics.'),
        'image'        => 'theme/assets/images/competitions/circuit-design.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/bDop0_Vd8jzDvK0Rf_n9-MOHVluSROuVCkDIaLHs5gBbiq2wMqp8j0aR4oum0aQOWL3NcR9CNs3eCRRU4zF55fxk47uUPW2n0rWYg3WNgLIr6wrvzvWZCQXk5MmGoyezTS9jH5URTSFwOoMYss5Y8ZnZWM-6rd8DZ-cN3Nk-Fxg?purpose=inline',
        'image_credit' => 'Competition Teams | Ohio Northern University',
        'rules_notice' => 'Detailed competition guidelines and testing parameters will be announced by the organizing committee.'
    ),
    array(
        'id'           => 'e-games',
        'number'       => '02',
        'title'        => 'E-Games',
        'category'     => 'gaming',
        'category_lbl' => 'Gaming & E-Sports',
        'track_code'   => 'C',
        'tagline'      => 'Online esports tournament featuring FIFA, COD, CS:GO & PUBG with live broadcasting',
        'desc'         => 'FIFA, COD, CS:GO and PUBG. Online, team-based competition with live broadcasting. Maximum four members per team. Final game selection depends on participant interests.',
        'full_desc'    => 'E-Games brings competitive gaming and esports to SIBACOM 2026. Held entirely online with public live broadcasting, teams of up to 4 battle across leading titles (FIFA, Call of Duty, CS:GO, PUBG). Final game selection depends on participant interests. The tournament fosters strategic planning, sharp reflexes, communication, and high-pressure teamwork.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Maximum 4 members per team',
        'min_team'     => 1,
        'max_team'     => 4,
        'format'       => 'Online Tournament with Live Broadcasting',
        'rounds_count' => 'Bracket Elimination Rounds',
        'games'        => array('FIFA', 'COD (Call of Duty)', 'CS:GO', 'PUBG'),
        'stages'       => null,
        'rubric'       => array('Tournament knockout bracket victories', 'In-game strategic execution and objective control', 'Teamwork, tactical positioning and squad communication'),
        'venue'        => 'Online Platform / Live Broadcast Stream',
        'venue_conf'   => true,
        'prizes'       => array(
            'first' => 'PKR 5,000',
            'second' => 'PKR 4,000',
            'third' => 'PKR 2,500',
            'total' => 11500,
            'pool_note' => 'Proposal budget allocation notes PKR 30,000 across multiple game brackets.'
        ),
        'workshop'     => null,
        'objectives'   => array('Enhance strategy-making, teamwork, and competitive nerves of students.', 'Crown the premier gaming champions of Sukkur IBA University.'),
        'image'        => 'theme/assets/images/competitions/e-games.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/0lt24NIBYhQbMGeCE9yUQX5hklGiBGxPh0wcqnSb6chU4vGZt6vcAmvVsn8NBzQAiqDm7LCVSvY24r_iyeLwL41FCIGJ1-Fh0XVbjBgnHjio-2r6_Hj2VgPHItOFsO3ICUKLEC5VvPKdcospalWm8pk07Gqn0I60We77aAdToCo?purpose=inline',
        'image_credit' => 'Level up in life: The surprising benefits of Esports participation',
        'rules_notice' => 'Game servers, anti-cheat enforcement, and lobby regulations will be announced by the gaming committee.'
    ),
    array(
        'id'           => 'robo-war',
        'number'       => '03',
        'title'        => 'Robo War',
        'category'     => 'hardware',
        'category_lbl' => 'Hardware & Engineering',
        'track_code'   => 'A',
        'tagline'      => 'Combat robotics arena showdown backed by an Arduino robot-building workshop',
        'desc'         => 'Basic robot-building workshop with Arduino and related equipment, followed by a robot competition under specified eligibility guidelines.',
        'full_desc'    => 'Robo War is SIBACOM’s flagship combat robotics tournament. Before entering the battle arena, teams participate in an intensive hands-on workshop covering robot chassis construction, Arduino microcontrollers, and motor drive systems. Mentors provide equipment and assist in assembling functional bots. Teams then clash inside a protected arena testing structural durability, kinetic weapon mechanics, and pilot strategy.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Team-based (2 to 4 members)',
        'min_team'     => 2,
        'max_team'     => 4,
        'format'       => 'Arena Combat Tournament & Pre-Event Workshop',
        'rounds_count' => 'Workshop + Tournament Brackets',
        'workshop'     => array(
            'title' => 'Basic Robot-Building Workshop',
            'desc'  => 'Workshop introducing basic robotics. Mentors provide basic equipment (such as Arduino and related components) and assist participants in building an eligible bot.',
            'items' => array('Arduino microcontrollers', 'Motor drivers & DC gear motors', 'Chassis assembly', 'Radio control & wireless receivers')
        ),
        'stages'       => null,
        'rubric'       => array('Robotics & engineering design', 'Creativity and armor durability', 'Practical problem-solving', 'Live combat arena performance'),
        'venue'        => 'Specialized Combat Arena (Campus Grounds)',
        'venue_conf'   => false,
        'prizes'       => array('first' => 'PKR 20,000', 'second' => 'PKR 15,000', 'third' => 'PKR 10,000', 'total' => 45000),
        'objectives'   => array('Help students choose career paths in AI and robotics.', 'Build confidence to compete in national and international competitions.', 'Demonstrate live engineering to a large audience.'),
        'image'        => 'theme/assets/images/competitions/robo-war.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/_2C7lnY2GkZxUM4rGTYcxX4j-XQMiz6uj_mPm1ouvXUvajM1C9EeCofy1lYSsiFCc0W2B3iqVEhBDv367nS9wSnuJKLlsDI1DhZzN-lhir0dv9JCgNQQYMzjiTJq6zvrSFaxE_njgtA2KRussacK_snTfmxvqZ6guF1l22ilVbw?purpose=inline',
        'image_credit' => 'Horseshoe Las Vegas: BattleBots Destruct-A-Thon | Book Online',
        'rules_notice' => 'Detailed guidelines regarding eligible robot weight classes, dimensions, weapon safety, and arena rules will be announced by the organizing committee.'
    ),
    array(
        'id'           => 'drone-competition',
        'number'       => '04',
        'title'        => 'Drone Competition',
        'category'     => 'hardware',
        'category_lbl' => 'Hardware & Engineering',
        'track_code'   => 'A',
        'tagline'      => 'UAV aerial navigation, obstacle traversal & precision flight with hands-on workshop',
        'desc'         => 'Drone-building and flying workshop, covering components, assembly, control and safe flying. Challenges evaluate maneuverability, accuracy, speed and control.',
        'full_desc'    => 'The Drone Competition challenges teams across aerial agility, obstacle navigation, speed, and precision flight control. Participants begin with a hands-on workshop on UAV principles, component assembly, radio telemetry, and safe flying practices with live demonstrations. Teams then compete through designated obstacle challenges testing control, maneuverability, and speed.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Team-based (2 to 4 members)',
        'min_team'     => 2,
        'max_team'     => 4,
        'format'       => 'Flight Course Trials & Technical Workshop',
        'rounds_count' => 'Workshop + Aerial Obstacle Heats',
        'workshop'     => array(
            'title' => 'Drone-Building & Safe Flying Workshop',
            'desc'  => 'Comprehensive introduction to fundamental drone components, working principles, frame assembly, radio calibration, and safe aerial navigation with live equipment demonstrations.',
            'items' => array('Drone frames & aerodynamics', 'Brushless motors & ESCs', 'Flight control boards & sensors', 'Transmitters, receivers & fail-safes')
        ),
        'stages'       => null,
        'rubric'       => array('Maneuverability through aerial obstacles', 'Flight accuracy, altitude and stability', 'Course completion speed and time trials', 'Drone control and technical pilot skills'),
        'venue'        => 'Designated Drone Arena / Flight Zone',
        'venue_conf'   => false,
        'prizes'       => array('first' => 'PKR 20,000', 'second' => 'PKR 15,000', 'third' => 'PKR 10,000', 'total' => 45000),
        'objectives'   => array('Develop practical engineering, technical, and problem-solving skills in UAVs.', 'Enhance understanding of flight control systems, sensors, electronics, and aerial navigation.'),
        'image'        => 'theme/assets/images/competitions/drone-competition.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/ctq3MctLC3A5csbyVFxmOlgGhzeTREelDpYAx5jSNtXExSjnfnm5ofZ3q9YUNRS1hC4mSAzOJi9WU62eEUw-BIJ-6wA45-4pSioH1vHzTFXF5Yny5J2WoUqzPTsohPUkbY8P1eF2HfbigEzaXmEbsgtsn5E8CNMKtFvdffYhUB4?purpose=inline',
        'image_credit' => 'FAI 2026 Drone Racing World Cup spans 13 countries, 15 events | Prism News',
        'rules_notice' => 'Detailed guidelines regarding drone dimensions, battery specifications, fail-safe cutoffs, and arena flight safety will be announced by the committee.'
    ),
    array(
        'id'           => 'lfr',
        'number'       => '05',
        'title'        => 'Line Following Robot (LFR)',
        'category'     => 'hardware',
        'category_lbl' => 'Hardware & Engineering',
        'track_code'   => 'A',
        'tagline'      => 'High-speed autonomous line navigation with IR sensor & microcontroller workshop',
        'desc'         => 'Workshop on Arduino, IR sensors, motors, motor drivers and robotics programming. Robots compete on a specially designed track based on speed, accuracy and completion time.',
        'full_desc'    => 'The Line Following Robot (LFR) competition challenges teams to design and program autonomous robotic vehicles capable of traversing a complex track with speed, precision, and zero deviation. Includes a dedicated workshop providing hands-on training with Arduino, IR sensor arrays, motor drivers, and closed-loop control algorithms. Robots race on an intricate track evaluated on navigation and lap time.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Team-based (2 to 4 members)',
        'min_team'     => 2,
        'max_team'     => 4,
        'format'       => 'Track Time Trials & Hardware Workshop',
        'rounds_count' => 'Workshop + Timed Track Runs',
        'workshop'     => array(
            'title' => 'LFR Building & Automation Workshop',
            'desc'  => 'Hands-on training covering robotics concepts, IR sensors, motor control, microcontrollers (Arduino), motor drivers, and robotics programming.',
            'items' => array('Arduino microcontrollers', 'IR reflective sensor arrays', 'High-speed DC gear motors', 'Motor driver ICs/shields', 'Robotics programming & PID logic')
        ),
        'stages'       => null,
        'rubric'       => array('Speed and lap completion time', 'Line-tracking accuracy and path adherence', 'Successful navigation through sharp turns and intersections', 'Reliability and overall completion time'),
        'venue'        => 'Specialized LFR Track Arena',
        'venue_conf'   => false,
        'prizes'       => array('first' => 'PKR 20,000', 'second' => 'PKR 15,000', 'third' => 'PKR 10,000', 'total' => 45000),
        'objectives'   => array('Develop practical engineering, programming, and embedded automation skills.', 'Optimize autonomous robotic systems for speed, accuracy, and reliability.'),
        'image'        => 'theme/assets/images/competitions/lfr.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/M7JMToZs1ixVIaEkmEjs96P9LtjsewQeIGL2syusuZiEGUGpjeSM37YvSw-GFKY20zkRlOHnx6XivD1AASg2x4zOmOPLcl3drczDgNguoUBpGtEv26AalLQLYg2ZaWro9PPim7Chk-vGOmknl8MFfHwOmM8u_m1jmi25n7pBk0I?purpose=inline',
        'image_credit' => 'International Robot Challenge',
        'rules_notice' => 'Detailed guidelines regarding robot chassis size, weight, track specifications, line thickness, and timer calibration will be announced by the committee.'
    ),
    array(
        'id'           => 'programming-challenge',
        'number'       => '06',
        'title'        => 'Programming Challenge',
        'category'     => 'computing',
        'category_lbl' => 'Computing & Technology',
        'track_code'   => 'B',
        'tagline'      => 'Two-round timed algorithmic coding contest hosted on HackerRank platform',
        'desc'         => 'Two HackerRank-based online-assessed rounds, each at least 60 minutes. Maximum two students per team. Venue: Lab-II and English Lab, AB-I.',
        'full_desc'    => 'Programming is one of the core subjects of Computer Systems and Electrical Engineering. The SIBACOM Programming Challenge tests algorithmic brilliance, data structure mastery, and code execution speed. Working in teams of up to 2 in Sukkur IBA’s state-of-the-art computer labs, participants solve challenging problem sets evaluated automatically on HackerRank over two rigorous rounds.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Maximum 2 students per team',
        'min_team'     => 1,
        'max_team'     => 2,
        'format'       => 'Two-Round Online Automated Contest',
        'rounds_count' => '2 Rounds (Min. 60 Minutes each)',
        'stages'       => null,
        'rubric'       => array('Automated test suite pass rate on HackerRank', 'Time and space complexity efficiency', 'Solve time with penalty adjustments for incorrect submissions', 'Algorithmic robustness'),
        'venue'        => 'Lab-II and English Lab, Academic Block-I (AB-I)',
        'venue_conf'   => true,
        'prizes'       => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000),
        'workshop'     => null,
        'objectives'   => array('Provide practical exposure to real-world coding problems and automated execution pipelines.', 'Sharpen algorithmic reasoning and execution speed under timed contest conditions.'),
        'image'        => 'theme/assets/images/competitions/programming-challenge.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/yXJtTOeu0g2ZLBkYbCqBdbUD2K5VbvIEqUsdftTmJiny04FBTknIxNqCakQXZibeNKWbiuAhZJym2iYyFFE2zdoSe9oexQ9p9n2_wYz7jkKpIQAyMZ6WXNvMU3ZYyhImQvikZAI63Khl9TKXNpY1UBE3hJpVfRGXMmiF7j5Y-zo?purpose=inline',
        'image_credit' => 'How Hackathons Can Boost Your Career as a Student | Mandala Suresh Kumar posted on the topic | LinkedIn',
        'rules_notice' => 'Contest environment details, language runtimes, and HackerRank contest access codes will be provided at the lab venue.'
    ),
    array(
        'id'           => 'ict-quiz',
        'number'       => '07',
        'title'        => 'ICT Quiz Contest',
        'category'     => 'computing',
        'category_lbl' => 'Computing & Technology',
        'track_code'   => 'B',
        'tagline'      => 'Individual fast-paced ICT knowledge battle hosted on Kahoot in the Auditorium',
        'desc'         => 'Individual participation, two rounds of 60 minutes each, initially using Kahoot. Venue: Auditorium.',
        'full_desc'    => 'The objective of the ICT Quiz Competition is to assess and enhance students’ knowledge of Information and Communication Technology (ICT) through an interactive, gamified environment. Competing individually in the Grand Auditorium over two 60-minute rounds on Kahoot, participants answer rapid-fire questions testing quick thinking, technical accuracy, and emerging technology awareness.',
        'fee'          => 'PKR 200 / participant',
        'fee_amount'   => 200,
        'fee_type'     => 'individual',
        'team_size'    => 'Individual participation (1 student)',
        'min_team'     => 1,
        'max_team'     => 1,
        'format'       => 'Two 60-Minute Interactive Kahoot Rounds',
        'rounds_count' => '2 Rounds (60 Minutes each)',
        'stages'       => null,
        'rubric'       => array('Kahoot interactive scoring combining accuracy and answer speed', 'Knowledge across ICT, computer architecture, networking, and software', 'Rapid decision-making under time pressure'),
        'venue'        => 'Auditorium, Sukkur IBA University',
        'venue_conf'   => true,
        'prizes'       => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000),
        'workshop'     => null,
        'objectives'   => array('Assess and enhance students’ knowledge of ICT through an interactive and competitive learning environment.', 'Develop quick thinking, accuracy, time management, and awareness of emerging technologies.'),
        'image'        => 'theme/assets/images/competitions/ict-quiz.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/42fSbEDjAe2HAwDrjvBxcQDJO3keD5dqLxptTH_eySCnGygV_5Ep4zLGHwwZKM0Tno6b4tos3NsPlY0uLLgKNDfWpEyRRez5rmHTdPFQJ7Bl4FB_KJRBFiWcZK71Xm-9yLLCAayHHgqkIAVR5BJgTSEeKk9mmUH66U-Eto_EiP4?purpose=inline',
        'image_credit' => 'Techpoint Future: Fremtidens teknologi - Tangen videregående skole',
        'rules_notice' => 'Participants must bring a connected smartphone or laptop for live Kahoot quiz session participation.'
    ),
    array(
        'id'           => 'project-exhibition',
        'number'       => '08',
        'title'        => 'Project Exhibition — Hardware & Software',
        'category'     => 'computing',
        'category_lbl' => 'Computing & Technology',
        'track_code'   => 'B',
        'tagline'      => 'Dual-tier hardware and software showcase for Junior & Senior innovators',
        'desc'         => 'Hardware and software project categories, divided into junior (up to semester 5) and senior (semester 6 onwards). Maximum four members per team. Venues: VFX Lab, FYP Lab and Fab Lab.',
        'full_desc'    => 'The Project Exhibition is SIBACOM’s premiere stage for applied student engineering. Open to both hardware prototypes and software applications, it features distinct Junior (up to 5th semester) and Senior (6th semester onwards) categories. Participants are encouraged to focus on high-impact theme areas: Medical, Climate, Agriculture, and General/Miscellaneous. Arduino workshops are held for junior batches to encourage prototype development.',
        'fee'          => 'PKR 500 / team',
        'fee_amount'   => 500,
        'fee_type'     => 'team',
        'team_size'    => 'Maximum 4 members per team',
        'min_team'     => 1,
        'max_team'     => 4,
        'format'       => 'Exhibition Booth Demonstration & Jury Defense',
        'rounds_count' => 'Exhibition Display & Live Faculty Defense',
        'academic_cat' => array(
            'junior' => 'Junior Category: Students up to 5th semester (Includes Arduino workshops)',
            'senior' => 'Senior Category: Students from 6th semester onwards'
        ),
        'project_types'=> array('Hardware Projects', 'Software Projects'),
        'themes'       => array('Medical', 'Climate', 'Agriculture', 'Miscellaneous / General'),
        'workshop'     => array(
            'title' => 'Arduino Prototyping Workshop for Junior Batches',
            'desc'  => 'Targeted hands-on sessions for junior students to learn rapid hardware prototyping and embedded software integration.',
            'items' => array('Arduino boards & sensor interfacing', 'Circuit assembly', 'Prototype debugging')
        ),
        'stages'       => null,
        'rubric'       => array('Rubrics and value added to theme areas', 'Practical novelty and technical complexity', 'Live prototype stability and working demonstration', 'Quality of team presentation and defense'),
        'venue'        => 'VFX Lab, FYP Lab and Fab Lab',
        'venue_conf'   => true,
        'prizes'       => array(
            'first' => 'PKR 15,000 (Hardware) | PKR 15,000 (Software)',
            'second' => 'PKR 10,000 (Hardware) | PKR 10,000 (Software)',
            'third' => 'PKR 5,000 (Hardware) | PKR 5,000 (Software)',
            'total' => 60000,
            'subcategories' => array(
                'hardware' => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000),
                'software' => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000)
            )
        ),
        'objectives'   => array('Provide an authentic showcase for student projects that add tangible value to society.', 'Build confidence in junior and senior students to demonstrate working solutions live to juries.'),
        'image'        => 'theme/assets/images/competitions/project-exhibition.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/Q46kpZQhFG2jIiL9nnstIG99U2A4aQwJx7iGmrSF7Y5KZl4QB7wvVzGmjmW7CfxcWT8rEg1wREc24_CNrtaxVUiFEXHTv1KAIpORUJ1p0ghlHr2Rfth-IO2XqASjP3P5Bd-2popKJ9eHgCwZ6PUe586heK2XeD_GOlhiSuJmTOo?purpose=inline',
        'image_credit' => 'Department of EECE | GITAM University Bengaluru.',
        'rules_notice' => 'Booth dimensions, power supply availability, and poster display guidelines will be communicated to registered teams.'
    ),
    array(
        'id'           => 'tug-of-war',
        'number'       => '09',
        'title'        => 'Fun Activities – Tug of War',
        'category'     => 'sports',
        'category_lbl' => 'Sports & Fun Activities',
        'track_code'   => 'D',
        'tagline'      => 'High-energy team showdown of synchronized power, strategy & endurance',
        'desc'         => 'Team-based physical challenge focusing on teamwork, synchronization, strength, strategy and endurance.',
        'full_desc'    => 'The ultimate showdown of grit, strategy, and raw, explosive power. Teams lock hands on the rope, digging their heels into the ground for a high-stakes test of pure endurance. Far more than raw force, success hinges on mastering friction, leverage, and synchronized timing. This high-energy challenge pushes participants to manage collective momentum and experience applied physics in athletic motion.',
        'fee'          => 'PKR 300 / team',
        'fee_amount'   => 300,
        'fee_type'     => 'team',
        'team_size'    => 'Team-based athletic challenge',
        'min_team'     => 4,
        'max_team'     => 8,
        'format'       => 'Knockout Bracket Heats on Grass Pitch',
        'rounds_count' => 'Elimination Heats to Finals',
        'workshop'     => null,
        'stages'       => null,
        'rubric'       => array('Synchronized pulling rhythm and collective momentum', 'Strategic application of friction, body angle, and foothold leverage', 'Endurance under sustained physical strain'),
        'venue'        => 'Campus Green Lawn / Sports Grounds',
        'venue_conf'   => false,
        'prizes'       => array('first' => 'PKR 15,000', 'second' => 'PKR 10,000', 'third' => 'PKR 5,000', 'total' => 30000),
        'objectives'   => array('Cultivate absolute unity, strategic alignment, and mental resilience under intense physical challenge.', 'Celebrate collective brilliance and applied physics in athletic motion.'),
        'image'        => 'theme/assets/images/competitions/tug-of-war.jpg',
        'image_remote' => 'https://images.openai.com/static-rsc-4/J2N4d8AmHB79VlYXfw-ld3bGVwSgesS2YMpBfg_v5j5Xras7IFHS9huw2bM6pjX4JgoRGcHKJKFe64YSxqoCFeTRYRa-HkWXxvaqi7kSbvcVAKaShTkqbi4MeEZt5lgm2Yfu5anB9BGXzT-93G2sUqNakJMopfq8JWChMXGaU-Y?purpose=inline',
        'image_credit' => 'History & Traditions - About Us - Schreyer Honors College (SHC) at Penn State University',
        'rules_notice' => 'Footwear restrictions, team weigh-in specifications, and match bracket rules will be announced before competition kick-off.'
    )
);

// Comprehensive Venues Allocation Matrix
$venues_list = array(
    array('name' => 'Auditorium', 'comps' => 'ICT Quiz Contest & Grand Prize Distribution Ceremony', 'building' => 'Main University Complex', 'capacity' => '800+ Seats'),
    array('name' => 'Lab-II', 'comps' => 'Programming Challenge (Round 1 & 2)', 'building' => 'Academic Block-I (AB-I)', 'capacity' => '60 Workstations'),
    array('name' => 'English Lab', 'comps' => 'Programming Challenge (Round 1 & 2)', 'building' => 'Academic Block-I (AB-I)', 'capacity' => '60 Workstations'),
    array('name' => 'VFX Lab', 'comps' => 'Project Exhibition (Hardware & Software)', 'building' => 'Innovation Block', 'capacity' => 'High-Performance Graphics'),
    array('name' => 'FYP Lab', 'comps' => 'Project Exhibition (Senior Final Year Projects)', 'building' => 'Engineering Complex', 'capacity' => 'Prototyping Benches'),
    array('name' => 'Fab Lab', 'comps' => 'Project Exhibition (Rapid Fabrication & Hardware)', 'building' => 'Fab Lab Facility', 'capacity' => 'Machining & 3D Print')
);
?>

<div class="sibacom-circuit-bg" style="padding-top: 2rem; padding-bottom: 6rem;">
    <div class="sibacom-container">
        
        <!-- ================= SECTION 1: HERO SECTION ================= -->
        <section class="sibacom-events-hero neu-card" style="margin-bottom: 3rem; padding: 3rem 2.5rem; background: linear-gradient(135deg, rgba(23,63,145,0.06) 0%, rgba(7,155,88,0.06) 100%); border-left: 6px solid var(--sibacom-primary, #173F91);">
            <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 1rem; margin-bottom: 1.5rem;">
                <div class="sibacom-badge">
                    <span class="pulse-dot"></span>
                    <span><?php esc_html_e('Sukkur IBA University • CSE Society & EE Society (SISC)', 'sibacom'); ?></span>
                </div>
                <div style="font-size: 0.85rem; font-family: monospace; color: var(--sibacom-techgreen, #079B58); font-weight: 700; background: rgba(7,155,88,0.08); padding: 0.35rem 0.85rem; border-radius: 9999px;">
                    <i class="fa-solid fa-file-circle-check" style="margin-right: 6px;"></i>
                    <?php esc_html_e('Official SIBACOM 2026 Proposal Specifications', 'sibacom'); ?>
                </div>
            </div>

            <h1 class="font-display" style="font-size: clamp(2.2rem, 4.5vw, 3.5rem); font-weight: 900; color: var(--sibacom-primary, #173F91); margin: 0 0 0.75rem; line-height: 1.15;">
                SIBACOM 2026 – <span style="color: var(--sibacom-navy, #102E68);">Competitions & Rewards</span>
            </h1>

            <p style="font-size: 1.25rem; font-weight: 700; color: var(--sibacom-techgreen, #079B58); margin: 0 0 1rem; letter-spacing: -0.01em;">
                Nine Flagship Activities. Technical Workshops. Real-World Challenges. Grand Cash Honors.
            </p>

            <p style="font-size: 1.05rem; color: var(--sibacom-text-secondary, #334155); max-width: 860px; line-height: 1.7; margin: 0 0 1.75rem;">
                Welcome to the complete, official competition index of SIBACOM 2026—jointly presented by the Electrical Engineering Society and Computer Systems Engineering Society of Sukkur IBA University. Explore all 9 competitive segments, hands-on Arduino and drone workshops, transparent fee schedules, and the audited cash prize fund of PKR 326,500 – 345,000.
            </p>

            <!-- Key Event Meta Pills -->
            <div style="display: flex; flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem;">
                <div style="display: flex; align-items: center; gap: 0.65rem; background: #fff; padding: 0.6rem 1.2rem; border-radius: 12px; box-shadow: 3px 3px 6px rgba(0,0,0,0.04), -3px -3px 6px #fff; font-size: 0.9rem;">
                    <i class="fa-regular fa-calendar-days" style="color: var(--sibacom-primary, #173F91);"></i>
                    <span><strong>Event Date:</strong> 26 November 2026 <small style="color: #D97706; margin-left: 4px;">(Proposed)</small></span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.65rem; background: #fff; padding: 0.6rem 1.2rem; border-radius: 12px; box-shadow: 3px 3px 6px rgba(0,0,0,0.04), -3px -3px 6px #fff; font-size: 0.9rem;">
                    <i class="fa-solid fa-location-dot" style="color: var(--sibacom-techgreen, #079B58);"></i>
                    <span><strong>Venue:</strong> Sukkur IBA University, Airport Road, Sukkur</span>
                </div>
                <div style="display: flex; align-items: center; gap: 0.65rem; background: #fff; padding: 0.6rem 1.2rem; border-radius: 12px; box-shadow: 3px 3px 6px rgba(0,0,0,0.04), -3px -3px 6px #fff; font-size: 0.9rem;">
                    <i class="fa-solid fa-trophy" style="color: #D97706;"></i>
                    <span><strong>Total Prize Fund:</strong> PKR 326,500 – 345,000</span>
                </div>
            </div>

            <!-- Quick Action CTAs -->
            <div style="display: flex; flex-wrap: wrap; gap: 1rem;">
                <a href="#competitions-matrix" class="sibacom-btn sibacom-btn-primary">
                    <span>Explore 9 Competitions</span>
                    <i class="fa-solid fa-arrow-down"></i>
                </a>
                <a href="#fee-calculator" class="sibacom-btn sibacom-btn-secondary">
                    <span>Fee Structure & Calculator</span>
                    <i class="fa-solid fa-calculator"></i>
                </a>
                <a href="#prize-pool" class="sibacom-btn" style="background: #fff; color: var(--sibacom-primary, #173F91); border: 1px solid rgba(23,63,145,0.2);">
                    <i class="fa-solid fa-award" style="color: #D97706; margin-right: 6px;"></i>
                    <span>Cash Prize Breakdown</span>
                </a>
                <a href="<?php echo esc_url($reg_portal_url); ?>" target="_blank" rel="noopener noreferrer" class="sibacom-btn" style="background: var(--sibacom-primary); color: #fff;">
                    <span>Official Registration Portal</span>
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                </a>
            </div>
        </section>

        <!-- ================= SECTION 2: ADVISORY BANNER ON ILLUSTRATIVE IMAGERY ================= -->
        <div class="neu-card" style="margin-bottom: 3rem; padding: 1.25rem 1.5rem; background: rgba(23,63,145,0.04); border-left: 4px solid var(--sibacom-primary, #173F91); display: flex; align-items: center; gap: 1rem; border-radius: 12px;">
            <div style="width: 40px; height: 40px; min-width: 40px; border-radius: 50%; background: rgba(23,63,145,0.1); color: var(--sibacom-primary); display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                <i class="fa-solid fa-circle-info"></i>
            </div>
            <div style="font-size: 0.92rem; color: var(--sibacom-text-secondary, #334155); line-height: 1.55;">
                <strong style="color: var(--sibacom-primary);">Official Advisory Note:</strong> Images displayed above and throughout the competition tracks are illustrative website imagery selected to represent the technical disciplines, not photographs of confirmed SIBACOM activities.
            </div>
        </div>

        <!-- ================= SECTION 3: EXECUTIVE OVERVIEW METRICS ================= -->
        <section style="margin-bottom: 3.5rem;">
            <div class="sibacom-section-header" style="margin-bottom: 2rem; text-align: left;">
                <div class="sibacom-badge">
                    <i class="fa-solid fa-chart-pie" style="color: var(--sibacom-techgreen, #079B58);"></i>
                    <span>Proposal Structure & High-Level Breakdown</span>
                </div>
                <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                    Competition Architecture at a Glance
                </h2>
                <p style="color: var(--sibacom-text-secondary, #334155); max-width: 760px; margin: 0;">
                    Nine main activities strategically divided across four official tracks, fostering hands-on technical learning, coding agility, robotics innovation, and healthy campus sportsmanship.
                </p>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem;">
                <!-- Card 1 -->
                <div class="neu-card" style="padding: 1.75rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <span style="font-size: 2.25rem; font-weight: 900; color: var(--sibacom-primary, #173F91); font-family: monospace;">09</span>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(23,63,145,0.1); display: flex; align-items: center; justify-content: center; color: var(--sibacom-primary, #173F91); font-size: 1.25rem;">
                            <i class="fa-solid fa-cubes"></i>
                        </div>
                    </div>
                    <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--sibacom-primary, #173F91); margin: 0 0 0.35rem;">Main Activities</h3>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary, #334155); margin: 0; line-height: 1.5;">
                        Complete competition roster verified directly from the official SIBACOM 2026 Event Proposal.
                    </p>
                </div>

                <!-- Card 2 -->
                <div class="neu-card" style="padding: 1.75rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <span style="font-size: 2.25rem; font-weight: 900; color: var(--sibacom-techgreen, #079B58); font-family: monospace;">04</span>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(7,155,88,0.1); display: flex; align-items: center; justify-content: center; color: var(--sibacom-techgreen, #079B58); font-size: 1.25rem;">
                            <i class="fa-solid fa-microchip"></i>
                        </div>
                    </div>
                    <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--sibacom-primary, #173F91); margin: 0 0 0.35rem;">Hardware & Robotics</h3>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary, #334155); margin: 0; line-height: 1.5;">
                        Circuit Design, Robo War, Drone Competition, and LFR with hands-on Arduino training workshops.
                    </p>
                </div>

                <!-- Card 3 -->
                <div class="neu-card" style="padding: 1.75rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <span style="font-size: 2.25rem; font-weight: 900; color: #0284C7; font-family: monospace;">03</span>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(2,132,199,0.1); display: flex; align-items: center; justify-content: center; color: #0284C7; font-size: 1.25rem;">
                            <i class="fa-solid fa-laptop-code"></i>
                        </div>
                    </div>
                    <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--sibacom-primary, #173F91); margin: 0 0 0.35rem;">Computing & Technology</h3>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary, #334155); margin: 0; line-height: 1.5;">
                        Programming Challenge (HackerRank), ICT Quiz Contest (Kahoot), and Project Exhibition (Hardware & Software).
                    </p>
                </div>

                <!-- Card 4 -->
                <div class="neu-card" style="padding: 1.75rem; background: linear-gradient(135deg, rgba(23,63,145,0.03) 0%, rgba(217,119,6,0.06) 100%);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <span style="font-size: 2.25rem; font-weight: 900; color: #B45309; font-family: monospace;">345K</span>
                        <div style="width: 44px; height: 44px; border-radius: 12px; background: rgba(217,119,6,0.15); display: flex; align-items: center; justify-content: center; color: #B45309; font-size: 1.25rem;">
                            <i class="fa-solid fa-trophy"></i>
                        </div>
                    </div>
                    <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--sibacom-primary, #173F91); margin: 0 0 0.35rem;">Cash Honors Fund</h3>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary, #334155); margin: 0; line-height: 1.5;">
                        Direct winner prize cheques presented on stage during the Grand Auditorium Award Ceremony.
                    </p>
                </div>
            </div>
        </section>

        <!-- ================= SECTION 4: INTERACTIVE COMPETITION MATRIX & FILTERS ================= -->
        <section id="competitions-matrix" style="margin-bottom: 4rem;">
            <div style="display: flex; flex-direction: column; md-flex-direction: row; justify-content: space-between; align-items: flex-start; gap: 1.5rem; margin-bottom: 2rem;">
                <div>
                    <div class="sibacom-badge">
                        <i class="fa-solid fa-filter" style="color: var(--sibacom-techgreen, #079B58);"></i>
                        <span>Categorized Competition Matrix</span>
                    </div>
                    <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                        Official Competition Segments
                    </h2>
                    <p style="color: var(--sibacom-text-secondary, #334155); max-width: 680px; margin: 0; font-size: 0.95rem;">
                        Filter by engineering discipline or search by technology (Arduino, HackerRank, Kahoot, IR sensors), team size, or venue.
                    </p>
                </div>

                <!-- Instant Search Box -->
                <div style="position: relative; width: 100%; max-width: 380px;">
                    <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 1.1rem; top: 50%; transform: translateY(-50%); color: var(--sibacom-text-secondary, #334155);"></i>
                    <input type="text" id="sibacom-event-search" placeholder="Search by name, Arduino, Kahoot, venue..." style="width: 100%; padding: 0.8rem 1rem 0.8rem 2.75rem; border-radius: 9999px; border: 1px solid rgba(23,63,145,0.18); background: #fff; font-size: 0.92rem; outline: none; box-shadow: inset 2px 2px 5px rgba(0,0,0,0.03);">
                </div>
            </div>

            <!-- 5 Official Category Filter Pills -->
            <div class="sibacom-category-pills" style="display: flex; gap: 0.65rem; margin-bottom: 2.5rem; flex-wrap: wrap;">
                <button type="button" class="neu-btn sibacom-cat-btn active" data-category="all" style="padding: 0.65rem 1.4rem; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    <i class="fa-solid fa-list-check" style="margin-right: 6px;"></i>All Competitions (9)
                </button>
                <button type="button" class="neu-btn sibacom-cat-btn" data-category="hardware" style="padding: 0.65rem 1.4rem; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    <i class="fa-solid fa-microchip" style="margin-right: 6px; color: var(--sibacom-primary, #173F91);"></i>Track A: Hardware & Engineering (4)
                </button>
                <button type="button" class="neu-btn sibacom-cat-btn" data-category="computing" style="padding: 0.65rem 1.4rem; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    <i class="fa-solid fa-code" style="margin-right: 6px; color: #0284C7;"></i>Track B: Computing & Technology (3)
                </button>
                <button type="button" class="neu-btn sibacom-cat-btn" data-category="gaming" style="padding: 0.65rem 1.4rem; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    <i class="fa-solid fa-gamepad" style="margin-right: 6px; color: #7C3AED;"></i>Track C: Gaming & E-Sports (1)
                </button>
                <button type="button" class="neu-btn sibacom-cat-btn" data-category="sports" style="padding: 0.65rem 1.4rem; font-weight: 700; font-size: 0.9rem; cursor: pointer;">
                    <i class="fa-solid fa-person-running" style="margin-right: 6px; color: var(--sibacom-techgreen, #079B58);"></i>Track D: Sports & Fun Activities (1)
                </button>
            </div>

            <!-- ================= 9 COMPETITION CARDS ================= -->
            <div id="sibacom-competitions-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(330px, 1fr)); gap: 2rem;">
                <?php foreach ($official_competitions as $comp) : ?>
                    <div class="sibacom-comp-card neu-card sibacom-card-circuit" data-id="<?php echo esc_attr($comp['id']); ?>" data-category="<?php echo esc_attr($comp['category']); ?>" style="display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; padding: 0; border: 1px solid rgba(23,63,145,0.08); transition: transform 0.25s ease, box-shadow 0.25s ease; position: relative;">
                        <?php if (function_exists('sibacom_the_circuit_corner')) {
                            sibacom_the_circuit_corner('tl');
                            sibacom_the_circuit_corner('br');
                        } ?>
                        
                        <!-- Media Header with Official Illustrative Imagery -->
                        <div style="position: relative; height: 215px; overflow: hidden; background: #17233D;">
                            <img src="<?php echo esc_url($comp['image']); ?>" 
                                 onerror="this.onerror=null; this.src='<?php echo esc_url($comp['image_remote']); ?>';" 
                                 alt="<?php echo esc_attr($comp['image_credit']); ?>" 
                                 loading="lazy" 
                                 decoding="async" 
                                 width="400" 
                                 height="215" 
                                 style="width: 100%; height: 100%; object-fit: cover; opacity: 1; transition: transform 0.4s ease;" />
                            <div style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(23,35,61,0.88) 100%);"></div>
                            
                            <!-- Badges Header -->
                            <div style="position: absolute; top: 12px; left: 12px; right: 12px; display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-family: monospace; font-size: 0.78rem; font-weight: 800; background: rgba(0,0,0,0.75); color: #FBBF24; padding: 0.3rem 0.7rem; border-radius: 6px; backdrop-filter: blur(4px);">
                                    #<?php echo esc_html($comp['number']); ?>
                                </span>
                                <span style="font-family: monospace; font-size: 0.8rem; font-weight: 800; background: rgba(7,155,88,0.92); color: #fff; padding: 0.3rem 0.8rem; border-radius: 6px; backdrop-filter: blur(4px); box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
                                    <i class="fa-solid fa-tag" style="margin-right: 4px;"></i><?php echo esc_html($comp['fee']); ?>
                                </span>
                            </div>

                            <!-- Bottom Title Overlay -->
                            <div style="position: absolute; bottom: 12px; left: 16px; right: 16px;">
                                <span style="display: inline-block; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; color: #fff; background: rgba(23,63,145,0.85); padding: 0.2rem 0.6rem; border-radius: 4px; margin-bottom: 4px;">
                                    Track <?php echo esc_html($comp['track_code']); ?> • <?php echo esc_html($comp['category_lbl']); ?>
                                </span>
                                <h3 class="font-display" style="margin: 0; font-size: 1.25rem; font-weight: 800; color: #fff; line-height: 1.3;">
                                    <?php echo esc_html($comp['title']); ?>
                                </h3>
                            </div>
                        </div>

                        <!-- Card Body -->
                        <div style="padding: 1.5rem; flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
                            <div>
                                <!-- Image Source Citation (Discreet & Professional) -->
                                <div style="font-size: 0.72rem; color: #64748B; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 4px; border-bottom: 1px dashed rgba(0,0,0,0.06); padding-bottom: 0.4rem;">
                                    <i class="fa-solid fa-camera-retro" style="opacity: 0.7;"></i>
                                    <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Illustrative Imagery: <?php echo esc_html($comp['image_credit']); ?></span>
                                </div>

                                <p style="font-size: 0.9rem; font-weight: 700; color: var(--sibacom-primary, #173F91); margin: 0 0 0.5rem; line-height: 1.4;">
                                    <?php echo esc_html($comp['tagline']); ?>
                                </p>
                                <p style="font-size: 0.88rem; color: var(--sibacom-text-secondary, #334155); margin: 0 0 1.25rem; line-height: 1.6;">
                                    <?php echo esc_html($comp['desc']); ?>
                                </p>

                                <!-- Core Specifications List -->
                                <div style="font-size: 0.82rem; font-family: monospace; border-top: 1px solid rgba(0,0,0,0.06); padding-top: 0.85rem; margin-bottom: 1.25rem; display: flex; flex-direction: column; gap: 0.5rem;">
                                    <div style="display: flex; justify-content: space-between;">
                                        <span style="color: var(--sibacom-text-muted);"><i class="fa-solid fa-users" style="margin-right: 6px;"></i>Team Size:</span>
                                        <strong style="color: var(--sibacom-primary);"><?php echo esc_html($comp['team_size']); ?></strong>
                                    </div>
                                    <div style="display: flex; justify-content: space-between;">
                                        <span style="color: var(--sibacom-text-muted);"><i class="fa-solid fa-location-dot" style="margin-right: 6px;"></i>Venue:</span>
                                        <strong style="color: <?php echo $comp['venue_conf'] ? 'var(--sibacom-techgreen)' : '#D97706'; ?>;">
                                            <?php echo $comp['venue_conf'] ? esc_html($comp['venue']) : 'Awaiting Final Allocation'; ?>
                                        </strong>
                                    </div>
                                    <?php if (!empty($comp['workshop'])) : ?>
                                        <div style="margin-top: 4px; padding: 0.45rem 0.65rem; background: rgba(217,119,6,0.08); border-radius: 6px; color: #B45309; font-size: 0.78rem;">
                                            <i class="fa-solid fa-wrench" style="margin-right: 5px;"></i>Workshop: <?php echo esc_html($comp['workshop']['title']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Prize Bar Strip -->
                            <div style="background: rgba(23,63,145,0.04); border: 1px solid rgba(23,63,145,0.08); border-radius: 10px; padding: 0.75rem 1rem; margin-bottom: 1.25rem; font-size: 0.82rem; font-family: monospace;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                                    <span><i class="fa-solid fa-award" style="color: #D97706; margin-right: 4px;"></i>Cash Honors:</span>
                                    <strong style="color: var(--sibacom-primary);">PKR <?php echo number_format($comp['prizes']['total']); ?></strong>
                                </div>
                                <div style="display: flex; justify-content: space-between; font-size: 0.78rem; color: var(--sibacom-text-secondary); border-top: 1px dashed rgba(0,0,0,0.08); padding-top: 4px;">
                                    <span>1st: <strong><?php echo esc_html($comp['prizes']['first']); ?></strong></span>
                                    <span>2nd: <strong><?php echo esc_html($comp['prizes']['second']); ?></strong></span>
                                    <span>3rd: <strong><?php echo esc_html($comp['prizes']['third']); ?></strong></span>
                                </div>
                            </div>

                            <!-- Card Action Buttons -->
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                                <button type="button" class="neu-btn" onclick="window.sibacomOpenDetails('<?php echo esc_js($comp['id']); ?>');" style="padding: 0.65rem 0.75rem; font-size: 0.85rem; font-weight: 700; cursor: pointer; text-align: center;">
                                    <i class="fa-solid fa-eye" style="margin-right: 5px;"></i>View Details
                                </button>
                                <a href="<?php echo esc_url($reg_portal_url); ?>" target="_blank" rel="noopener noreferrer" class="sibacom-btn sibacom-btn-primary" style="padding: 0.65rem 0.75rem; font-size: 0.85rem; font-weight: 700; justify-content: center; text-decoration: none;">
                                    <span>Register</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Empty Search State -->
            <div id="sibacom-empty-search" style="display: none; padding: 3rem 1.5rem; text-align: center; margin: 2rem auto; max-width: 500px;" class="neu-card">
                <i class="fa-solid fa-magnifying-glass" style="font-size: 2.5rem; color: var(--sibacom-text-muted); margin-bottom: 1rem;"></i>
                <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--sibacom-primary); margin: 0 0 0.5rem;">No matching competitions</h3>
                <p style="font-size: 0.9rem; color: var(--sibacom-text-secondary); margin: 0 0 1.25rem;">
                    Try clearing your search query or selecting "All Competitions".
                </p>
                <button type="button" class="neu-btn" onclick="document.getElementById('sibacom-event-search').value=''; window.sibacomFilterCategory('all');">
                    Reset Filters
                </button>
            </div>
        </section>

        <!-- ================= SECTION 5: REGISTRATION FEE STRUCTURE & CALCULATOR ================= -->
        <section id="fee-calculator" style="margin-bottom: 4.5rem;">
            <div class="sibacom-section-header" style="margin-bottom: 2.5rem; text-align: left;">
                <div class="sibacom-badge">
                    <i class="fa-solid fa-receipt" style="color: var(--sibacom-techgreen, #079B58);"></i>
                    <span>Official Registration Fee Schedule</span>
                </div>
                <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                    Registration Fee Structure & Delegation Calculator
                </h2>
                <p style="color: var(--sibacom-text-secondary, #334155); max-width: 760px; margin: 0;">
                    Complete fee schedule extracted verbatim from the SIBACOM proposal. Select competitions below to dynamically calculate your team’s or university delegation’s registration fee.
                </p>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 2rem; align-items: start;">
                
                <!-- Complete Fee Schedule Table -->
                <div class="neu-card" style="padding: 0; overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.92rem;">
                        <thead>
                            <tr style="background: rgba(23,63,145,0.06); border-bottom: 1px solid rgba(0,0,0,0.08); font-family: monospace; font-size: 0.8rem; text-transform: uppercase;">
                                <th style="padding: 1rem 1.25rem;">#</th>
                                <th style="padding: 1rem;">Competition</th>
                                <th style="padding: 1rem;">Participation Type</th>
                                <th style="padding: 1rem 1.25rem; text-align: right;">Registration Fee</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">01</td><td style="padding: 0.85rem; font-weight: 700;">Circuit Design</td><td style="padding: 0.85rem; color: #64748B;">Team (2 Students)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">02</td><td style="padding: 0.85rem; font-weight: 700;">E-Games</td><td style="padding: 0.85rem; color: #64748B;">Team (Max 4)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">03</td><td style="padding: 0.85rem; font-weight: 700;">Robo War</td><td style="padding: 0.85rem; color: #64748B;">Team (Workshop included)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">04</td><td style="padding: 0.85rem; font-weight: 700;">Drone Competition</td><td style="padding: 0.85rem; color: #64748B;">Team (Workshop included)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">05</td><td style="padding: 0.85rem; font-weight: 700;">Line Following Robot (LFR)</td><td style="padding: 0.85rem; color: #64748B;">Team (Workshop included)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">06</td><td style="padding: 0.85rem; font-weight: 700;">Programming Challenge</td><td style="padding: 0.85rem; color: #64748B;">Team (Max 2 Students)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05); background: rgba(7,155,88,0.03);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700; color: var(--sibacom-techgreen);">07</td><td style="padding: 0.85rem; font-weight: 700; color: var(--sibacom-techgreen);">ICT Quiz Contest</td><td style="padding: 0.85rem; color: var(--sibacom-techgreen); font-weight: 600;">Individual (Kahoot)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-techgreen);">PKR 200 / person</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">08</td><td style="padding: 0.85rem; font-weight: 700;">Project Exhibition (HW & SW)</td><td style="padding: 0.85rem; color: #64748B;">Team (Max 4 Members)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 500 / team</td></tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.85rem 1.25rem; font-family: monospace; font-weight: 700;">09</td><td style="padding: 0.85rem; font-weight: 700;">Tug of War</td><td style="padding: 0.85rem; color: #64748B;">Team (Athletic challenge)</td><td style="padding: 0.85rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">PKR 300 / team</td></tr>
                        </tbody>
                    </table>
                </div>

                <!-- Interactive Fee Calculator Box -->
                <div class="neu-card" style="padding: 2rem; background: linear-gradient(135deg, rgba(23,63,145,0.04) 0%, rgba(7,155,88,0.05) 100%);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
                        <h3 class="font-display" style="margin: 0; font-size: 1.35rem; color: var(--sibacom-primary);">
                            <i class="fa-solid fa-calculator" style="margin-right: 8px; color: var(--sibacom-techgreen);"></i>Delegation Fee Calculator
                        </h3>
                        <span id="calc-count-pill" style="font-family: monospace; font-size: 0.75rem; background: var(--sibacom-primary); color: #fff; padding: 0.2rem 0.6rem; border-radius: 9999px;">0 Selected</span>
                    </div>
                    <p style="font-size: 0.88rem; color: var(--sibacom-text-secondary); margin: 0 0 1.25rem;">
                        Check the modules your team or university squad plans to enter:
                    </p>

                    <div style="display: flex; flex-direction: column; gap: 0.65rem; margin-bottom: 1.5rem; max-height: 280px; overflow-y: auto; padding-right: 4px;">
                        <?php foreach ($official_competitions as $c) : ?>
                            <label style="display: flex; align-items: center; justify-content: space-between; padding: 0.6rem 0.85rem; background: #fff; border: 1px solid rgba(0,0,0,0.06); border-radius: 8px; cursor: pointer; font-size: 0.88rem; transition: background 0.15s ease;">
                                <div style="display: flex; align-items: center; gap: 0.65rem;">
                                    <input type="checkbox" class="sibacom-calc-cb" value="<?php echo esc_attr($c['fee_amount']); ?>" data-name="<?php echo esc_attr($c['title']); ?>" style="width: 17px; height: 17px; cursor: pointer;">
                                    <span><?php echo esc_html($c['title']); ?></span>
                                </div>
                                <span style="font-family: monospace; font-weight: 700; color: var(--sibacom-primary);"><?php echo esc_html($c['fee']); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <!-- Calculator Total Box -->
                    <div style="padding: 1.25rem; background: #fff; border-radius: 12px; border: 1px solid rgba(23,63,145,0.12); display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
                        <div>
                            <span style="font-size: 0.75rem; font-family: monospace; text-transform: uppercase; color: #64748B; display: block;">Total Registration Due</span>
                            <span id="calc-total-display" class="font-display" style="font-size: 1.85rem; font-weight: 900; color: var(--sibacom-primary); line-height: 1;">PKR 0</span>
                        </div>
                        <button type="button" class="neu-btn" onclick="window.sibacomResetCalculator();" style="font-size: 0.8rem; padding: 0.4rem 0.8rem; cursor: pointer;">
                            <i class="fa-solid fa-rotate-left" style="margin-right: 4px;"></i>Reset
                        </button>
                    </div>

                    <a href="<?php echo esc_url($reg_portal_url); ?>" target="_blank" rel="noopener noreferrer" class="sibacom-btn sibacom-btn-primary" style="width: 100%; justify-content: center; text-decoration: none;">
                        <span>Proceed to Official Registration Desk</span>
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                </div>

            </div>
        </section>

        <!-- ================= SECTION 6: PRIZE DISTRIBUTION & HONORS ================= -->
        <section id="prize-pool" style="margin-bottom: 4.5rem;">
            <div class="sibacom-section-header" style="margin-bottom: 2.5rem; text-align: left;">
                <div class="sibacom-badge">
                    <i class="fa-solid fa-award" style="color: #D97706;"></i>
                    <span>Official Cash Grants, Trophies & Merit Certificates</span>
                </div>
                <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                    SIBACOM 2026 Prize Pool & Honors
                </h2>
                <p style="color: var(--sibacom-text-secondary, #334155); max-width: 760px; margin: 0;">
                    Complete audited cash prize allocation distributed across 10 competitive tracks, presented in the form of official winner cheques during the Auditorium grand finale.
                </p>
            </div>

            <!-- Grand Podium Card -->
            <div class="neu-card" style="padding: 2.5rem; margin-bottom: 2rem; background: linear-gradient(135deg, rgba(23,63,145,0.05) 0%, rgba(217,119,6,0.08) 100%); border-left: 6px solid #D97706;">
                <div style="display: flex; flex-direction: column; md-flex-direction: row; justify-content: space-between; align-items: center; gap: 2rem; flex-wrap: wrap;">
                    <div>
                        <span style="font-family: monospace; font-size: 0.8rem; text-transform: uppercase; font-weight: 800; color: #D97706; display: block; margin-bottom: 4px;">
                            Official Cash Prize Allocation
                        </span>
                        <div class="font-display" style="font-size: clamp(2.5rem, 5vw, 3.5rem); font-weight: 900; color: var(--sibacom-primary, #173F91); line-height: 1;">
                            PKR 326,500 – 345,000
                        </div>
                        <p style="font-size: 0.95rem; color: var(--sibacom-text-secondary); margin: 0.75rem 0 0; max-width: 520px; line-height: 1.6;">
                            Awarded via official printed cheques during the Grand Award Ceremony in the Auditorium in the concluding hours of SIBACOM.
                        </p>
                    </div>

                    <!-- 3-Tier Podium Visual -->
                    <div style="display: flex; align-items: flex-end; gap: 0.85rem; text-align: center;">
                        <!-- 2nd -->
                        <div style="width: 110px;">
                            <div style="font-size: 0.75rem; font-weight: 800; color: #64748B; margin-bottom: 6px;">2nd Place</div>
                            <div style="background: #E2E8F0; padding: 1.25rem 0.5rem; border-radius: 12px 12px 0 0; border: 1px solid #CBD5E1;">
                                <i class="fa-solid fa-medal" style="font-size: 1.5rem; color: #64748B; margin-bottom: 4px;"></i>
                                <div style="font-size: 0.85rem; font-weight: 800; color: #1E293B;">10K - 15K</div>
                                <div style="font-size: 0.7rem; color: #64748B;">Silver Shield</div>
                            </div>
                        </div>

                        <!-- 1st -->
                        <div style="width: 125px;">
                            <div style="font-size: 0.8rem; font-weight: 800; color: #D97706; margin-bottom: 6px;"><i class="fa-solid fa-crown" style="margin-right: 4px;"></i>1st Place</div>
                            <div style="background: linear-gradient(180deg, #FEF3C7 0%, #FDE68A 100%); padding: 2rem 0.5rem; border-radius: 14px 14px 0 0; border: 2px solid #F59E0B; box-shadow: 0 10px 15px -3px rgba(245,158,11,0.2);">
                                <i class="fa-solid fa-trophy" style="font-size: 2rem; color: #D97706; margin-bottom: 6px;"></i>
                                <div style="font-size: 1rem; font-weight: 900; color: #78350F;">15K - 20K</div>
                                <div style="font-size: 0.72rem; font-weight: 700; color: #92400E;">Gold Trophy</div>
                            </div>
                        </div>

                        <!-- 3rd -->
                        <div style="width: 110px;">
                            <div style="font-size: 0.75rem; font-weight: 800; color: #B45309; margin-bottom: 6px;">3rd Place</div>
                            <div style="background: #FFEDD5; padding: 0.85rem 0.5rem; border-radius: 12px 12px 0 0; border: 1px solid #FDBA74;">
                                <i class="fa-solid fa-award" style="font-size: 1.35rem; color: #B45309; margin-bottom: 4px;"></i>
                                <div style="font-size: 0.85rem; font-weight: 800; color: #7C2D12;">5K - 10K</div>
                                <div style="font-size: 0.7rem; color: #9A3412;">Bronze Shield</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Complete Table Breakdown Extracted from Proposal -->
            <div class="neu-card" style="padding: 0; overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.92rem;">
                    <thead>
                        <tr style="background: rgba(23,63,145,0.06); border-bottom: 1px solid rgba(0,0,0,0.08); font-family: monospace; font-size: 0.8rem; text-transform: uppercase;">
                            <th style="padding: 1rem 1.25rem;">Competition</th>
                            <th style="padding: 1rem;">1st Prize</th>
                            <th style="padding: 1rem;">2nd Prize</th>
                            <th style="padding: 1rem;">3rd Prize</th>
                            <th style="padding: 1rem 1.25rem; text-align: right;">Subtotal (PKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Circuit Design</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Programming Challenge</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">ICT Quiz</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">E-Games</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">5,000</td><td style="padding: 0.9rem;">4,000</td><td style="padding: 0.9rem;">2,500</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">11,500 <small style="color: #64748B; font-weight: 400;">(Pool: 30k)</small></td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Robo War</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">20,000</td><td style="padding: 0.9rem;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">45,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Drone Competition</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">20,000</td><td style="padding: 0.9rem;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">45,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05); background: rgba(23,63,145,0.02);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Project Exhibition – Hardware</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05); background: rgba(23,63,145,0.02);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Project Exhibition – Software</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Line Following Robot (LFR)</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">20,000</td><td style="padding: 0.9rem;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">45,000</td></tr>
                        <tr style="border-bottom: 1px solid rgba(0,0,0,0.05);"><td style="padding: 0.9rem 1.25rem; font-weight: 700;">Tug of War</td><td style="padding: 0.9rem; color: #D97706; font-weight: 700;">15,000</td><td style="padding: 0.9rem;">10,000</td><td style="padding: 0.9rem;">5,000</td><td style="padding: 0.9rem 1.25rem; text-align: right; font-weight: 800; color: var(--sibacom-primary);">30,000</td></tr>
                    </tbody>
                    <tfoot>
                        <tr style="background: rgba(23,63,145,0.08); font-weight: 900; font-family: monospace; font-size: 0.95rem;">
                            <td style="padding: 1rem 1.25rem; color: var(--sibacom-primary);">Grand Total Cash Prize Fund</td>
                            <td style="padding: 1rem; color: #D97706;">155,000</td>
                            <td style="padding: 1rem;">109,000</td>
                            <td style="padding: 1rem;">62,500</td>
                            <td style="padding: 1rem 1.25rem; text-align: right; color: var(--sibacom-primary);">PKR 326,500 – 345,000</td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Additional Honors Beyond Cash -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 1.5rem; margin-top: 2rem;">
                <div class="neu-card" style="padding: 1.5rem; border-top: 4px solid #D97706;">
                    <i class="fa-solid fa-money-check-dollar" style="font-size: 1.5rem; color: #D97706; margin-bottom: 0.75rem;"></i>
                    <h4 style="margin: 0 0 0.4rem; font-size: 1.05rem; color: var(--sibacom-primary); font-weight: 800;">Winner Prize Cheques</h4>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary); margin: 0; line-height: 1.5;">
                        Ceremonial and printed winner cheques (40 printed cheques allocated) handed over on stage during the award ceremony.
                    </p>
                </div>
                <div class="neu-card" style="padding: 1.5rem; border-top: 4px solid var(--sibacom-techgreen);">
                    <i class="fa-solid fa-certificate" style="font-size: 1.5rem; color: var(--sibacom-techgreen); margin-bottom: 0.75rem;"></i>
                    <h4 style="margin: 0 0 0.4rem; font-size: 1.05rem; color: var(--sibacom-primary); font-weight: 800;">700+ Official Certificates</h4>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary); margin: 0; line-height: 1.5;">
                        Official certificates of merit and participation provided to all verified contestants and student volunteers.
                    </p>
                </div>
                <div class="neu-card" style="padding: 1.5rem; border-top: 4px solid var(--sibacom-primary);">
                    <i class="fa-solid fa-microchip" style="font-size: 1.5rem; color: var(--sibacom-primary); margin-bottom: 0.75rem;"></i>
                    <h4 style="margin: 0 0 0.4rem; font-size: 1.05rem; color: var(--sibacom-primary); font-weight: 800;">Hardware Kits for Teams</h4>
                    <p style="font-size: 0.85rem; color: var(--sibacom-text-secondary); margin: 0; line-height: 1.5;">
                        Official Arduino kits, chassis, sensors, wheels, transmitters, and receivers provided for hands-on workshop learning.
                    </p>
                </div>
            </div>
        </section>

        <!-- ================= SECTION 7: REGISTRATION PROCESS & HELP DESKS ================= -->
        <section style="margin-bottom: 4.5rem;">
            <div class="sibacom-section-header" style="margin-bottom: 2rem; text-align: left;">
                <div class="sibacom-badge">
                    <i class="fa-solid fa-map-location-dot" style="color: var(--sibacom-techgreen, #079B58);"></i>
                    <span>Campus Registration Desks & Participating Universities</span>
                </div>
                <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                    Registration Process & Physical Help Desks
                </h2>
                <p style="color: var(--sibacom-text-secondary, #334155); max-width: 760px; margin: 0;">
                    Registration is conducted through dedicated help desks on the Sukkur IBA University campus and online through the portal.
                </p>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                <div class="neu-card" style="padding: 1.5rem; text-align: center;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(23,63,145,0.08); color: var(--sibacom-primary); display: flex; align-items: center; justify-content: center; font-size: 1.25rem; margin: 0 auto 1rem;">
                        <i class="fa-solid fa-building-columns"></i>
                    </div>
                    <h4 style="margin: 0 0 0.35rem; font-size: 1rem; color: var(--sibacom-primary); font-weight: 800;">Academic Block-1</h4>
                    <p style="font-size: 0.82rem; color: var(--sibacom-text-secondary); margin: 0;">Help desk located outside main lobby for CSE & EE students.</p>
                </div>
                <div class="neu-card" style="padding: 1.5rem; text-align: center;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(7,155,88,0.08); color: var(--sibacom-techgreen); display: flex; align-items: center; justify-content: center; font-size: 1.25rem; margin: 0 auto 1rem;">
                        <i class="fa-solid fa-landmark"></i>
                    </div>
                    <h4 style="margin: 0 0 0.35rem; font-size: 1rem; color: var(--sibacom-primary); font-weight: 800;">Academic Block-2</h4>
                    <p style="font-size: 0.82rem; color: var(--sibacom-text-secondary); margin: 0;">Registration desk for general and inter-departmental entries.</p>
                </div>
                <div class="neu-card" style="padding: 1.5rem; text-align: center;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(2,132,199,0.08); color: #0284C7; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; margin: 0 auto 1rem;">
                        <i class="fa-solid fa-cube"></i>
                    </div>
                    <h4 style="margin: 0 0 0.35rem; font-size: 1rem; color: var(--sibacom-primary); font-weight: 800;">Academic Block-3</h4>
                    <p style="font-size: 0.82rem; color: var(--sibacom-text-secondary); margin: 0;">Central Secretariat and help desk for high-tech competitions.</p>
                </div>
                <div class="neu-card" style="padding: 1.5rem; text-align: center;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(217,119,6,0.08); color: #D97706; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; margin: 0 auto 1rem;">
                        <i class="fa-solid fa-book-bookmark"></i>
                    </div>
                    <h4 style="margin: 0 0 0.35rem; font-size: 1rem; color: var(--sibacom-primary); font-weight: 800;">Knowledge Center</h4>
                    <p style="font-size: 0.82rem; color: var(--sibacom-text-secondary); margin: 0;">Help desk outside central library for campus-wide participants.</p>
                </div>
            </div>

            <!-- Expected Participating Universities -->
            <div class="neu-card" style="padding: 1.75rem; background: #fff;">
                <h4 class="font-display" style="font-size: 1.15rem; color: var(--sibacom-primary); margin: 0 0 1rem;">
                    <i class="fa-solid fa-graduation-cap" style="margin-right: 8px; color: var(--sibacom-techgreen);"></i>Expected Participating Universities & Colleges
                </h4>
                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; font-size: 0.82rem; font-family: monospace;">
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">Mehran University of Engineering and Technology, Jamshoro</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">MUCET Khairpur Campus</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">Quaid-e-Awam University (QUEST), Nawabshah</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">QUEST Larkana Campus</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">Shah Abdul Latif University (SALU), Khairpur</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">SZABIST Larkana</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">SZABIST Hyderabad</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">ISRA University Hyderabad</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">University of Sindh, Jamshoro</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">Bahria University, Karachi</span>
                    <span style="padding: 0.35rem 0.75rem; background: #F1F5F9; border-radius: 6px; color: #334155;">Dawood University of Engineering and Technology (DUET), Karachi</span>
                </div>
            </div>
        </section>

        <!-- ================= SECTION 8: CAMPUS VENUES ================= -->
        <section style="margin-bottom: 4.5rem;">
            <div class="sibacom-section-header" style="margin-bottom: 2rem; text-align: left;">
                <div class="sibacom-badge">
                    <i class="fa-solid fa-building" style="color: var(--sibacom-techgreen, #079B58);"></i>
                    <span>Campus Facilities & Laboratories</span>
                </div>
                <h2 class="font-display" style="font-size: 2rem; color: var(--sibacom-primary, #173F91); margin: 0.5rem 0 0.35rem;">
                    Designated Event Venues
                </h2>
                <p style="color: var(--sibacom-text-secondary, #334155); max-width: 760px; margin: 0;">
                    All officially designated competition venues located on Sukkur IBA University’s 20-acre modern campus on Airport Road, Sukkur.
                </p>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 1.75rem;">
                <?php foreach ($venues_list as $v) : ?>
                    <div class="neu-card" style="padding: 1.5rem; border-top: 4px solid var(--sibacom-techgreen);">
                        <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.75rem;">
                            <div style="width: 38px; height: 38px; border-radius: 10px; background: rgba(7,155,88,0.1); color: var(--sibacom-techgreen); display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                                <i class="fa-solid fa-door-open"></i>
                            </div>
                            <div>
                                <h4 style="margin: 0; font-size: 1.1rem; color: var(--sibacom-primary); font-weight: 700;"><?php echo esc_html($v['name']); ?></h4>
                                <span style="font-size: 0.75rem; font-family: monospace; color: var(--sibacom-text-secondary);"><?php echo esc_html($v['building']); ?> • <?php echo esc_html($v['capacity']); ?></span>
                            </div>
                        </div>
                        <div style="font-size: 0.85rem; color: var(--sibacom-text-secondary); line-height: 1.5;">
                            <strong>Allocated Segments:</strong> <?php echo esc_html($v['comps']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

    </div>
</div>

<!-- ================= DYNAMIC DETAILS MODAL ================= -->
<div id="sibacom-detail-modal" style="display: none; position: fixed; inset: 0; z-index: 9999; background: rgba(16,46,104,0.68); backdrop-filter: blur(4px); align-items: center; justify-content: center; padding: 1.25rem;">
    <div class="neu-card" style="position: relative; width: 100%; max-width: 820px; max-height: 90vh; display: flex; flex-direction: column; background: #fff; padding: 0; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
        
        <!-- Modal Header -->
        <div style="padding: 1.5rem 1.75rem; border-bottom: 1px solid rgba(0,0,0,0.08); background: #F8FAFC; display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
                <span id="mdl-cat-badge" style="display: inline-block; font-size: 0.72rem; font-family: monospace; font-weight: 800; text-transform: uppercase; color: var(--sibacom-primary); background: rgba(23,63,145,0.08); padding: 0.2rem 0.6rem; border-radius: 4px; margin-bottom: 4px;"></span>
                <h2 id="mdl-title" class="font-display" style="margin: 0; font-size: 1.65rem; color: var(--sibacom-primary); font-weight: 800;"></h2>
                <div id="mdl-tagline" style="font-size: 0.88rem; color: var(--sibacom-techgreen); font-weight: 600; margin-top: 2px;"></div>
            </div>
            <button type="button" onclick="window.sibacomCloseDetails();" aria-label="Close modal" style="background: none; border: none; font-size: 1.5rem; color: #64748B; cursor: pointer; padding: 4px;">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <!-- Modal Body Content -->
        <div id="mdl-body" style="padding: 1.75rem; overflow-y: auto; flex: 1; font-size: 0.95rem; line-height: 1.6; color: var(--sibacom-text-primary);">
            <!-- Populated dynamically via JavaScript -->
        </div>

        <!-- Modal Footer -->
        <div style="padding: 1.25rem 1.75rem; border-top: 1px solid rgba(0,0,0,0.08); background: #F8FAFC; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <div id="mdl-fee-summary" style="font-size: 0.9rem; font-family: monospace; font-weight: 700; color: var(--sibacom-primary);"></div>
            <div style="display: flex; gap: 0.75rem;">
                <button type="button" class="neu-btn" onclick="window.sibacomCloseDetails();" style="padding: 0.6rem 1.2rem; cursor: pointer;">Close</button>
                <a id="mdl-register-btn" href="<?php echo esc_url($reg_portal_url); ?>" target="_blank" rel="noopener noreferrer" class="sibacom-btn sibacom-btn-primary" style="padding: 0.6rem 1.4rem; text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem;">
                    <span>Register for Event</span>
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- ================= JAVASCRIPT CONTROLLERS ================= -->
<script>
window.sibacomCompetitionsData = <?php echo json_encode($official_competitions); ?>;

// Category Filter Controller
window.sibacomFilterCategory = function(cat) {
    var buttons = document.querySelectorAll('.sibacom-cat-btn');
    buttons.forEach(function(btn) {
        if (btn.getAttribute('data-category') === cat) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    var cards = document.querySelectorAll('.sibacom-comp-card');
    var visibleCount = 0;
    var searchVal = (document.getElementById('sibacom-event-search').value || '').toLowerCase().trim();

    cards.forEach(function(card) {
        var cardCat = card.getAttribute('data-category') || '';
        var cardText = card.textContent.toLowerCase();

        var matchesCat = (cat === 'all' || cardCat === cat);
        var matchesSearch = (!searchVal || cardText.indexOf(searchVal) !== -1);

        if (matchesCat && matchesSearch) {
            card.style.display = 'flex';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });

    var emptyState = document.getElementById('sibacom-empty-search');
    if (emptyState) {
        emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
    }
};

// Search Controller
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('sibacom-event-search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var activeBtn = document.querySelector('.sibacom-cat-btn.active');
            var currentCat = activeBtn ? activeBtn.getAttribute('data-category') : 'all';
            window.sibacomFilterCategory(currentCat);
        });
    }

    var catButtons = document.querySelectorAll('.sibacom-cat-btn');
    catButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var cat = this.getAttribute('data-category');
            window.sibacomFilterCategory(cat);
        });
    });

    // Checkbox calculator listener
    var calcCheckboxes = document.querySelectorAll('.sibacom-calc-cb');
    calcCheckboxes.forEach(function(cb) {
        cb.addEventListener('change', window.sibacomUpdateCalculator);
    });

    // Check URL parameters for direct deep-linking (?module=... or ?category=...)
    var urlParams = new URLSearchParams(window.location.search);
    var modParam = urlParams.get('module');
    if (modParam) {
        window.sibacomOpenDetails(modParam);
    }
    var catParam = urlParams.get('category');
    if (catParam) {
        window.sibacomFilterCategory(catParam);
    }
});

// Calculator Controller
window.sibacomUpdateCalculator = function() {
    var checkboxes = document.querySelectorAll('.sibacom-calc-cb:checked');
    var total = 0;
    checkboxes.forEach(function(cb) {
        total += parseInt(cb.value, 10) || 0;
    });

    var display = document.getElementById('calc-total-display');
    if (display) {
        display.textContent = 'PKR ' + total.toLocaleString();
    }
    var pill = document.getElementById('calc-count-pill');
    if (pill) {
        pill.textContent = checkboxes.length + ' Selected';
    }
};

window.sibacomResetCalculator = function() {
    var checkboxes = document.querySelectorAll('.sibacom-calc-cb');
    checkboxes.forEach(function(cb) {
        cb.checked = false;
    });
    window.sibacomUpdateCalculator();
};

// Detail Modal Controller
window.sibacomOpenDetails = function(compId) {
    var comp = window.sibacomCompetitionsData.find(function(c) { return c.id === compId; });
    if (!comp) return;

    document.getElementById('mdl-cat-badge').textContent = 'Track ' + comp.track_code + ' • ' + comp.category_lbl;
    document.getElementById('mdl-title').textContent = comp.title;
    document.getElementById('mdl-tagline').textContent = comp.tagline;
    document.getElementById('mdl-fee-summary').textContent = 'Registration Fee: ' + comp.fee + ' | ' + comp.team_size;

    var regBtn = document.getElementById('mdl-register-btn');
    if (regBtn) {
        var baseRegUrl = <?php echo json_encode(esc_url($reg_portal_url)); ?>;
        regBtn.href = baseRegUrl ? (baseRegUrl + (baseRegUrl.indexOf('?') !== -1 ? '&' : '?') + 'event=' + encodeURIComponent(comp.id)) : '#';
    }

    var html = '';
    html += '<div style="margin-bottom: 1.5rem;"><h4 style="font-size: 0.8rem; font-family: monospace; text-transform: uppercase; color: #64748B; margin: 0 0 0.4rem;">01. Overview & Activity Details</h4>';
    html += '<p style="margin: 0; font-size: 0.95rem; line-height: 1.6; color: #334155;">' + comp.full_desc + '</p></div>';

    if (comp.stages && comp.stages.length) {
        html += '<div style="margin-bottom: 1.5rem;"><h4 style="font-size: 0.8rem; font-family: monospace; text-transform: uppercase; color: #64748B; margin: 0 0 0.5rem;">02. Format & Progression Stages</h4>';
        comp.stages.forEach(function(stg) {
            html += '<div style="padding: 0.75rem 1rem; background: #F8FAFC; border-radius: 8px; border: 1px solid #E2E8F0; margin-bottom: 0.5rem;">';
            html += '<strong style="color: var(--sibacom-primary);">' + stg.name + ':</strong> ';
            html += '<span style="color: #475569; font-size: 0.9rem;">' + stg.desc + '</span></div>';
        });
        html += '</div>';
    } else {
        html += '<div style="margin-bottom: 1.5rem;"><h4 style="font-size: 0.8rem; font-family: monospace; text-transform: uppercase; color: #64748B; margin: 0 0 0.5rem;">02. Competition Format</h4>';
        html += '<div style="padding: 0.75rem 1rem; background: #F8FAFC; border-radius: 8px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.9rem;">';
        html += '<strong>Format:</strong> ' + comp.format + ' • <strong>Rounds:</strong> ' + comp.rounds_count + '</div></div>';
    }

    if (comp.workshop) {
        html += '<div style="margin-bottom: 1.5rem; padding: 1rem; background: rgba(217,119,6,0.06); border-radius: 10px; border: 1px solid rgba(217,119,6,0.2);">';
        html += '<h4 style="font-size: 0.85rem; font-family: monospace; text-transform: uppercase; color: #B45309; margin: 0 0 0.35rem;"><i class="fa-solid fa-wrench" style="margin-right: 6px;"></i>03. Pre-Event Technical Workshop</h4>';
        html += '<strong style="display: block; font-size: 0.95rem; color: #78350F; margin-bottom: 4px;">' + comp.workshop.title + '</strong>';
        html += '<p style="font-size: 0.88rem; color: #92400E; margin: 0 0 0.5rem; line-height: 1.5;">' + comp.workshop.desc + '</p>';
        html += '<div style="display: flex; flex-wrap: wrap; gap: 4px;">';
        comp.workshop.items.forEach(function(it) {
            html += '<span style="font-size: 0.75rem; font-family: monospace; background: #fff; border: 1px solid #FCD34D; padding: 0.2rem 0.5rem; border-radius: 4px; color: #78350F;">' + it + '</span>';
        });
        html += '</div></div>';
    }

    html += '<div style="margin-bottom: 1.5rem;"><h4 style="font-size: 0.8rem; font-family: monospace; text-transform: uppercase; color: #64748B; margin: 0 0 0.5rem;">04. Adjudication & Evaluation Rubric</h4><ul style="margin: 0; padding-left: 1.25rem; font-size: 0.9rem; color: #475569;">';
    comp.rubric.forEach(function(r) {
        html += '<li style="margin-bottom: 4px;">' + r + '</li>';
    });
    html += '</ul></div>';

    html += '<div style="margin-bottom: 1.5rem;"><h4 style="font-size: 0.8rem; font-family: monospace; text-transform: uppercase; color: #64748B; margin: 0 0 0.5rem;">05. Official Cash Prizes (PKR ' + comp.prizes.total.toLocaleString() + ')</h4>';
    html += '<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0.5rem; text-align: center;">';
    html += '<div style="padding: 0.75rem; background: #FEF3C7; border: 1px solid #FDE68A; border-radius: 8px;"><strong>1st: ' + comp.prizes.first + '</strong></div>';
    html += '<div style="padding: 0.75rem; background: #F1F5F9; border: 1px solid #E2E8F0; border-radius: 8px;"><strong>2nd: ' + comp.prizes.second + '</strong></div>';
    html += '<div style="padding: 0.75rem; background: #FFEDD5; border: 1px solid #FED7AA; border-radius: 8px;"><strong>3rd: ' + comp.prizes.third + '</strong></div>';
    html += '</div>';
    if (comp.prizes.pool_note) {
        html += '<div style="margin-top: 6px; padding: 0.5rem; background: #FEF3C7; border-radius: 6px; font-size: 0.75rem; color: #92400E; font-family: monospace;">' + comp.prizes.pool_note + '</div>';
    }
    html += '</div>';

    html += '<div style="padding: 0.85rem; background: #FEF2F2; border: 1px solid #FECACA; border-radius: 8px; font-size: 0.85rem; color: #991B1B;">';
    html += '<strong><i class="fa-solid fa-shield-halved" style="margin-right: 5px;"></i>Rules Notice:</strong> "' + comp.rules_notice + '"</div>';

    document.getElementById('mdl-body').innerHTML = html;
    document.getElementById('sibacom-detail-modal').style.display = 'flex';
};

window.sibacomCloseDetails = function() {
    document.getElementById('sibacom-detail-modal').style.display = 'none';
};
</script>

<?php
    } // End of else (non-Elementor fallback)
endwhile;

get_footer();
