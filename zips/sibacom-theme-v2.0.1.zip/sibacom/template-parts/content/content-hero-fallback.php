<?php
/**
 * SIBACOM Theme Fallback Hero Template Part
 *
 * @package SIBACOM
 */

if (!defined('ABSPATH')) {
    exit;
}

$hero_bg       = sibacom_get_campus_bg_url();
$hero_headline = sibacom_get_option('hero_headline', 'Connecting Ideas. Empowering Innovation. Building Tomorrow.');
$hero_desc     = sibacom_get_option('hero_description', 'Pakistan’s premier collegiate technology festival convening top student programmers, robotics engineers, AI researchers, and startup founders for high-stakes competition at Sukkur IBA University.');
$event_dates   = sibacom_get_option('event_dates', 'November 30, 2026');
$event_venue   = sibacom_get_option('event_venue', 'Academic Block-III, Sukkur IBA University');
$cta_url       = sibacom_get_option('header_cta_url', '#contact');
$target_date   = sibacom_get_option('hero_countdown_date', '2026-11-30T09:00:00');
?>
<section class="sibacom-hero-wrap">
    <div class="sibacom-hero-bg">
        <img src="<?php echo esc_url($hero_bg); ?>" alt="<?php esc_attr_e('Sukkur IBA University Campus', 'sibacom'); ?>" width="1024" height="576" fetchpriority="high" decoding="async" />
        <div class="sibacom-hero-overlay-v"></div>
        <div class="sibacom-hero-overlay-h"></div>
    </div>

    <?php if (function_exists('sibacom_the_hero_circuits')) { sibacom_the_hero_circuits(); } ?>

    <div class="sibacom-container">
        <div class="sibacom-hero-content">
            
            <!-- Institutional Badge -->
            <div class="sibacom-badge" style="margin-bottom: 1.5rem;">
                <span class="pulse-dot"></span>
                <span><?php esc_html_e('Sukkur IBA University Presents • National Tech Olympiad', 'sibacom'); ?></span>
            </div>

            <!-- Event Title: SIBACOM -->
            <h1 class="sibacom-hero-title font-display">
                <span class="sibacom-gradient-text">SIBACOM</span>
                <span style="color: var(--sibacom-techgreen); font-size: 0.55em; vertical-align: super; font-family: monospace;">'26</span>
            </h1>

            <!-- Headline -->
            <p class="sibacom-hero-tagline">
                <?php echo esc_html($hero_headline); ?>
            </p>

            <!-- Description -->
            <p class="sibacom-hero-description">
                <?php echo esc_html($hero_desc); ?>
            </p>

            <!-- Metadata Pill Bar -->
            <div class="sibacom-meta-bar">
                <div class="sibacom-meta-item">
                    <i class="fa-regular fa-calendar-days"></i>
                    <span><?php echo esc_html($event_dates); ?></span>
                </div>
                <div class="sibacom-meta-divider"></div>
                <div class="sibacom-meta-item">
                    <i class="fa-solid fa-location-dot"></i>
                    <span><?php echo esc_html($event_venue); ?></span>
                </div>
                <div class="sibacom-meta-divider"></div>
                <div class="sibacom-meta-item">
                    <i class="fa-solid fa-users"></i>
                    <span><?php esc_html_e('1,500+ Innovators', 'sibacom'); ?></span>
                </div>
            </div>

            <!-- Countdown Timer -->
            <div class="sibacom-countdown" data-target-date="<?php echo esc_attr($target_date); ?>">
                <div class="sibacom-countdown-box">
                    <span class="sibacom-countdown-number days-val">00</span>
                    <span class="sibacom-countdown-label"><?php esc_html_e('Days', 'sibacom'); ?></span>
                </div>
                <div class="sibacom-countdown-box">
                    <span class="sibacom-countdown-number hours-val">00</span>
                    <span class="sibacom-countdown-label"><?php esc_html_e('Hours', 'sibacom'); ?></span>
                </div>
                <div class="sibacom-countdown-box">
                    <span class="sibacom-countdown-number minutes-val">00</span>
                    <span class="sibacom-countdown-label"><?php esc_html_e('Mins', 'sibacom'); ?></span>
                </div>
                <div class="sibacom-countdown-box">
                    <span class="sibacom-countdown-number seconds-val">00</span>
                    <span class="sibacom-countdown-label"><?php esc_html_e('Secs', 'sibacom'); ?></span>
                </div>
            </div>

            <!-- CTAs -->
            <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; margin-top: 2rem;">
                <a href="<?php echo esc_url($cta_url); ?>" class="sibacom-btn sibacom-btn-primary">
                    <span><?php esc_html_e('Register for SIBACOM', 'sibacom'); ?></span>
                    <i class="fa-solid fa-arrow-right"></i>
                </a>
                <a href="#about" class="sibacom-btn sibacom-btn-secondary">
                    <span><?php esc_html_e('Explore Event Details', 'sibacom'); ?></span>
                    <i class="fa-solid fa-circle-info"></i>
                </a>
            </div>

        </div>
    </div>
</section>

