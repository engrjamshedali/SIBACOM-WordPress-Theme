<?php
/**
 * SIBACOM Events & Pricing Elementor Widget
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;

class SIBACOM_Events_Widget extends Widget_Base {

    public function get_name() {
        return 'sibacom_events';
    }

    public function get_title() {
        return esc_html__('SIBACOM Events & Pricing', 'sibacom-manager');
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories() {
        return array('sibacom-elements');
    }

    protected function register_controls() {
        // CONTENT TAB: Source & Query
        $this->start_controls_section(
            'section_content_source',
            array(
                'label' => esc_html__('Event Query & Display Mode', 'sibacom-manager'),
            )
        );

        $this->add_control(
            'data_mode',
            array(
                'label'   => esc_html__('Data Source Mode', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'dynamic',
                'options' => array(
                    'dynamic' => esc_html__('Dynamic (WordPress CPT / SIBACOM Events)', 'sibacom-manager'),
                    'manual'  => esc_html__('Custom Manual Repeater (Visual Editor)', 'sibacom-manager'),
                ),
            )
        );

        $this->add_control(
            'columns',
            array(
                'label'   => esc_html__('Grid Columns', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => '3',
                'options' => array(
                    '1' => esc_html__('1 Column (Full Width)', 'sibacom-manager'),
                    '2' => esc_html__('2 Columns (Split)', 'sibacom-manager'),
                    '3' => esc_html__('3 Columns (Standard Grid)', 'sibacom-manager'),
                    '4' => esc_html__('4 Columns (Compact Grid)', 'sibacom-manager'),
                ),
            )
        );

        $this->add_control(
            'limit',
            array(
                'label'     => esc_html__('Number of Events to Show (-1 for All)', 'sibacom-manager'),
                'type'      => Controls_Manager::NUMBER,
                'default'   => 7,
                'condition' => array(
                    'data_mode' => 'dynamic',
                ),
            )
        );

        $this->add_control(
            'featured_only',
            array(
                'label'        => esc_html__('Only Featured Events', 'sibacom-manager'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'sibacom-manager'),
                'label_off'    => esc_html__('No', 'sibacom-manager'),
                'return_value' => 'yes',
                'default'      => '',
                'condition'    => array(
                    'data_mode' => 'dynamic',
                ),
            )
        );

        // Manual Repeater
        $repeater = new Repeater();

        $repeater->add_control(
            'event_title',
            array(
                'label'   => esc_html__('Event Title', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Speed Programming League',
            )
        );

        $repeater->add_control(
            'event_category',
            array(
                'label'   => esc_html__('Category Tag', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Competitive Programming',
            )
        );

        $repeater->add_control(
            'event_banner',
            array(
                'label'   => esc_html__('Banner Image', 'sibacom-manager'),
                'type'    => Controls_Manager::MEDIA,
                'default' => array(
                    'url' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
                ),
            )
        );

        $repeater->add_control(
            'event_desc',
            array(
                'label'   => esc_html__('Short Description', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => 'Timed algorithmic coding sprint featuring strict automated test suites in C++, Java, and Python under ACM rules.',
            )
        );

        $repeater->add_control(
            'event_date',
            array(
                'label'   => esc_html__('Event Date', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'November 30, 2026',
            )
        );

        $repeater->add_control(
            'event_start_time',
            array(
                'label'   => esc_html__('Start Time', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '09:00 AM',
            )
        );

        $repeater->add_control(
            'event_end_time',
            array(
                'label'   => esc_html__('End Time', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '01:00 PM',
            )
        );

        $repeater->add_control(
            'event_venue',
            array(
                'label'   => esc_html__('Event Venue', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'CSE Lab 1 & 2',
            )
        );

        $repeater->add_control(
            'event_price',
            array(
                'label'   => esc_html__('Pricing Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'PKR 1,000',
            )
        );

        $repeater->add_control(
            'event_fee_type',
            array(
                'label'   => esc_html__('Pricing Category', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'paid',
                'options' => array(
                    'free'    => esc_html__('Free Registration', 'sibacom-manager'),
                    'paid'    => esc_html__('Standard Fee (PKR)', 'sibacom-manager'),
                    'team'    => esc_html__('Team Registration', 'sibacom-manager'),
                    'special' => esc_html__('Special Category', 'sibacom-manager'),
                ),
            )
        );

        $repeater->add_control(
            'event_reg_close',
            array(
                'label'   => esc_html__('Registration Closing Date', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Nov 25, 2026',
            )
        );

        $repeater->add_control(
            'event_status',
            array(
                'label'   => esc_html__('Registration Status', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'open',
                'options' => array(
                    'open'         => esc_html__('Registration Open', 'sibacom-manager'),
                    'not_open'     => esc_html__('Coming Soon', 'sibacom-manager'),
                    'closing_soon' => esc_html__('Closing Soon', 'sibacom-manager'),
                    'closed'       => esc_html__('Registration Closed', 'sibacom-manager'),
                    'full'         => esc_html__('Fully Booked', 'sibacom-manager'),
                ),
            )
        );

        $repeater->add_control(
            'event_visibility',
            array(
                'label'   => esc_html__('Visibility', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'visible',
                'options' => array(
                    'visible' => esc_html__('Visible', 'sibacom-manager'),
                    'hidden'  => esc_html__('Hidden', 'sibacom-manager'),
                ),
            )
        );

        $repeater->add_control(
            'event_url',
            array(
                'label'   => esc_html__('Registration CTA URL', 'sibacom-manager'),
                'type'    => Controls_Manager::URL,
                'default' => array(
                    'url' => 'https://iba-suk.edu.pk/sibacom/register',
                ),
            )
        );

        $repeater->add_control(
            'event_btn_text',
            array(
                'label'   => esc_html__('Button Label Override', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Register Now',
            )
        );

        $this->add_control(
            'manual_events',
            array(
                'label'       => esc_html__('Manual Event Items (All 7 Cards)', 'sibacom-manager'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ event_title }}}',
                'condition'   => array(
                    'data_mode' => 'manual',
                ),
                'default'     => array(
                    array(
                        'event_title'      => 'Speed Programming League',
                        'event_category'   => 'Competitive Programming',
                        'event_price'      => 'PKR 1,000',
                        'event_fee_type'   => 'paid',
                        'event_date'       => 'November 30, 2026',
                        'event_start_time' => '09:00 AM',
                        'event_end_time'   => '01:00 PM',
                        'event_venue'      => 'CSE Labs 1 & 2',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Now',
                        'event_desc'       => 'Timed algorithmic coding sprint featuring strict automated test suites in C++, Java, and Python under ACM rules.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'SIBACOM Hackathon 24H',
                        'event_category'   => 'Software Innovation',
                        'event_price'      => 'PKR 2,500/Team',
                        'event_fee_type'   => 'team',
                        'event_date'       => 'November 30 – December 01, 2026',
                        'event_start_time' => '10:00 AM',
                        'event_end_time'   => '10:00 AM',
                        'event_venue'      => 'Executive Innovation Hall',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Team',
                        'event_desc'       => 'Continuous 24-hour product build sprint tackling high-impact problems across sovereign AI agents, smart city infrastructure, and fintech.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'Capture The Flag (CTF) Cyber Defense',
                        'event_category'   => 'Cybersecurity',
                        'event_price'      => 'PKR 1,500/Team',
                        'event_fee_type'   => 'team',
                        'event_date'       => 'December 01, 2026',
                        'event_start_time' => '09:30 AM',
                        'event_end_time'   => '05:30 PM',
                        'event_venue'      => 'Cyber Security Research Lab',
                        'event_status'     => 'closing_soon',
                        'event_btn_text'   => 'Register Team',
                        'event_desc'       => 'Jeopardy-style offensive & defensive cyber challenge: binary exploitation, cryptography, web exploitation, and network forensics.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'RoboWars & Autonomous Arena',
                        'event_category'   => 'Robotics & Hardware',
                        'event_price'      => 'PKR 2,000/Team',
                        'event_fee_type'   => 'team',
                        'event_date'       => 'December 01, 2026',
                        'event_start_time' => '10:00 AM',
                        'event_end_time'   => '04:30 PM',
                        'event_venue'      => 'Sports Complex Arena & Robotics Lab',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Team',
                        'event_desc'       => 'Featherweight combat robot clashes and autonomous line-following micro-maze navigation across calibrated arena hazards.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'AI Agent Innovation Challenge',
                        'event_category'   => 'Artificial Intelligence',
                        'event_price'      => 'PKR 1,000',
                        'event_fee_type'   => 'paid',
                        'event_date'       => 'December 02, 2026',
                        'event_start_time' => '09:00 AM',
                        'event_end_time'   => '03:00 PM',
                        'event_venue'      => 'Artificial Intelligence Research Lab',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Now',
                        'event_desc'       => 'Benchmark challenge for building autonomous multimodal agent workflows, enterprise LLM copilots, and local edge inferences.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'Startup Showcase & Venture Pitching',
                        'event_category'   => 'Venture & Pitching',
                        'event_price'      => 'Free Registration',
                        'event_fee_type'   => 'free',
                        'event_date'       => 'December 02, 2026',
                        'event_start_time' => '11:00 AM',
                        'event_end_time'   => '04:00 PM',
                        'event_venue'      => 'Executive Boardroom, Academic Block-III',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Startup',
                        'event_desc'       => 'Collegiate founders pitch validated software and hardware prototypes directly before accredited venture capitalists and angel networks.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=800&q=80'),
                    ),
                    array(
                        'event_title'      => 'UI/UX Design Sprint',
                        'event_category'   => 'Product & UI/UX Design',
                        'event_price'      => 'PKR 800',
                        'event_fee_type'   => 'paid',
                        'event_date'       => 'November 30, 2026',
                        'event_start_time' => '10:00 AM',
                        'event_end_time'   => '04:00 PM',
                        'event_venue'      => 'Design & Multimedia Studio, Sukkur IBA',
                        'event_status'     => 'open',
                        'event_btn_text'   => 'Register Now',
                        'event_desc'       => 'Fast-paced product discovery, design systems challenge, wireframing, and interactive prototyping sprint evaluated on usability and visual elegance.',
                        'event_banner'     => array('url' => 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?auto=format&fit=crop&w=800&q=80'),
                    ),
                ),
            )
        );

        $this->end_controls_section();

        // STYLE TAB: Card Styling
        $this->start_controls_section(
            'section_style_cards',
            array(
                'label' => esc_html__('Card & Neumorphism Styling', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'card_bg',
            array(
                'label'     => esc_html__('Card Background Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FFFFFF',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-event-card' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'card_radius',
            array(
                'label'      => esc_html__('Card Border Radius', 'sibacom-manager'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array('px', 'rem'),
                'range'      => array(
                    'px' => array('min' => 0, 'max' => 40),
                ),
                'default'    => array('unit' => 'px', 'size' => 24),
                'selectors'  => array(
                    '{{WRAPPER}} .sibacom-event-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'card_box_shadow',
                'label'    => esc_html__('Card Box Shadow', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .sibacom-event-card',
            )
        );

        $this->end_controls_section();

        // STYLE TAB: Typography & Colors
        $this->start_controls_section(
            'section_style_typography',
            array(
                'label' => esc_html__('Typography & Colors', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'label'    => esc_html__('Title Typography', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .sibacom-event-card-title',
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label'     => esc_html__('Title Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#17233D',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-event-card-title' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'desc_color',
            array(
                'label'     => esc_html__('Description Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#64748B',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-event-card-desc' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_section();

        // STYLE TAB: Button Styling
        $this->start_controls_section(
            'section_style_button',
            array(
                'label' => esc_html__('Registration Button Styling', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'btn_bg',
            array(
                'label'     => esc_html__('Button Background', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#173F91',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-btn-primary' => 'background: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'btn_text_color',
            array(
                'label'     => esc_html__('Button Text Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FFFFFF',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-btn-primary' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_section();

        // Style Tab: Card Circuit Accents & Hover Signals
        $this->start_controls_section(
            'section_style_card_circuits',
            array(
                'label' => esc_html__('Card Circuit Accents & Hover Signals', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'enable_card_circuits',
            array(
                'label'        => esc_html__('Enable Circuit Corner Accents', 'sibacom-manager'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'sibacom-manager'),
                'label_off'    => esc_html__('No', 'sibacom-manager'),
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $this->add_control(
            'card_circuit_color',
            array(
                'label'     => esc_html__('Circuit Corner Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(23, 63, 145, 0.22)',
                'selectors' => array(
                    '{{WRAPPER}}' => '--sibacom-circuit-trace: {{VALUE}};',
                ),
                'condition' => array('enable_card_circuits' => 'yes'),
            )
        );

        $this->add_control(
            'card_pulse_color',
            array(
                'label'     => esc_html__('Hover Signal Accent Color', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#079B58',
                'selectors' => array(
                    '{{WRAPPER}}' => '--sibacom-circuit-techgreen: {{VALUE}};',
                ),
                'condition' => array('enable_card_circuits' => 'yes'),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $mode     = $settings['data_mode'];
        $cols     = !empty($settings['columns']) ? $settings['columns'] : '3';
        $limit    = !empty($settings['limit']) ? $settings['limit'] : -1;
        $featured = !empty($settings['featured_only']) ? 'yes' : '';

        if ($mode === 'dynamic') {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_events(array(
                    'limit'    => $limit,
                    'featured' => $featured,
                    'columns'  => $cols,
                ));
            }
        } else {
            // Render manual repeater items
            $events = !empty($settings['manual_events']) ? $settings['manual_events'] : array();
            ?>
            <div class="sibacom-events-grid col-<?php echo esc_attr($cols); ?>">
                <?php foreach ($events as $item) : 
                    if (!empty($item['event_visibility']) && $item['event_visibility'] === 'hidden') {
                        continue;
                    }
                    $banner_url = !empty($item['event_banner']['url']) ? $item['event_banner']['url'] : 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80';
                    $url = !empty($item['event_url']['url']) ? $item['event_url']['url'] : 'https://iba-suk.edu.pk/sibacom/register';
                    $status_key = !empty($item['event_status']) ? $item['event_status'] : 'open';

                    switch ($status_key) {
                        case 'open':
                            $label = esc_html__('Registration Open', 'sibacom-manager');
                            $cls = 'status-open';
                            $active = true;
                            break;
                        case 'closing_soon':
                            $label = esc_html__('Closing Soon', 'sibacom-manager');
                            $cls = 'status-closing';
                            $active = true;
                            break;
                        case 'not_open':
                            $label = esc_html__('Coming Soon', 'sibacom-manager');
                            $cls = 'status-upcoming';
                            $active = false;
                            break;
                        case 'full':
                            $label = esc_html__('Fully Booked', 'sibacom-manager');
                            $cls = 'status-full';
                            $active = false;
                            break;
                        default:
                            $label = esc_html__('Registration Closed', 'sibacom-manager');
                            $cls = 'status-closed';
                            $active = false;
                            break;
                    }
                    ?>
                    <div class="sibacom-event-card neu-card sibacom-card-circuit">
                        <?php if ((!isset($settings['enable_card_circuits']) || $settings['enable_card_circuits'] !== 'no') && function_exists('sibacom_the_circuit_corner')) : ?>
                            <?php sibacom_the_circuit_corner('tl'); ?>
                            <?php sibacom_the_circuit_corner('br'); ?>
                        <?php endif; ?>
                        <div class="sibacom-event-banner sibacom-event-card-media">
                            <img src="<?php echo esc_url($banner_url); ?>" alt="<?php echo esc_attr($item['event_title']); ?>" width="600" height="338" loading="lazy" decoding="async" />
                            <div class="sibacom-event-badges-bar sibacom-event-badges">
                                <span class="sibacom-price-badge price-<?php echo esc_attr($item['event_fee_type']); ?>">
                                    <i class="fa-solid fa-tag"></i>
                                    <?php echo esc_html($item['event_price']); ?>
                                </span>
                                <span class="sibacom-status-badge <?php echo esc_attr($cls); ?>">
                                    <span class="status-indicator"></span>
                                    <?php echo esc_html($label); ?>
                                </span>
                            </div>
                        </div>

                        <div class="sibacom-event-card-body">
                            <?php if (!empty($item['event_category'])) : ?>
                                <div style="margin-bottom: 0.35rem;">
                                    <span style="display: inline-block; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--sibacom-primary, #173F91); background: rgba(23,63,145,0.08); padding: 0.2rem 0.6rem; border-radius: 4px;">
                                        <?php echo esc_html($item['event_category']); ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <h3 class="sibacom-event-card-title font-display"><?php echo esc_html($item['event_title']); ?></h3>
                            <div class="sibacom-event-card-desc">
                                <p><?php echo esc_html($item['event_desc']); ?></p>
                            </div>

                            <div class="sibacom-event-meta-list">
                                <div class="sibacom-event-meta-row">
                                    <i class="fa-regular fa-calendar" style="color: var(--sibacom-primary);"></i>
                                    <span><strong><?php esc_html_e('Date:', 'sibacom-manager'); ?></strong> <?php echo esc_html($item['event_date']); ?></span>
                                </div>
                                <?php if (!empty($item['event_start_time']) || !empty($item['event_end_time'])) : ?>
                                    <div class="sibacom-event-meta-row">
                                        <i class="fa-regular fa-clock" style="color: var(--sibacom-techgreen);"></i>
                                        <span><strong><?php esc_html_e('Time:', 'sibacom-manager'); ?></strong> <?php echo esc_html(trim($item['event_start_time'] . ' - ' . $item['event_end_time'], ' -')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="sibacom-event-meta-row">
                                    <i class="fa-solid fa-location-dot" style="color: var(--sibacom-techgreen);"></i>
                                    <span><strong><?php esc_html_e('Venue:', 'sibacom-manager'); ?></strong> <?php echo esc_html($item['event_venue']); ?></span>
                                </div>
                                <?php if (!empty($item['event_reg_close'])) : ?>
                                    <div class="sibacom-event-meta-row">
                                        <i class="fa-regular fa-hourglass-half" style="color: #D97706;"></i>
                                        <span><strong><?php esc_html_e('Closing Date:', 'sibacom-manager'); ?></strong> <?php echo esc_html($item['event_reg_close']); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="sibacom-event-card-footer">
                                <?php if ($active) : ?>
                                    <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" class="sibacom-btn sibacom-btn-primary sibacom-btn-full">
                                        <span><?php echo esc_html($item['event_btn_text']); ?></span>
                                        <i class="fa-solid fa-arrow-right"></i>
                                    </a>
                                <?php else : ?>
                                    <button class="sibacom-btn sibacom-btn-disabled sibacom-btn-full" disabled="disabled">
                                        <span><?php echo esc_html($item['event_btn_text']); ?></span>
                                        <i class="fa-solid fa-lock"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
        }
    }
}

