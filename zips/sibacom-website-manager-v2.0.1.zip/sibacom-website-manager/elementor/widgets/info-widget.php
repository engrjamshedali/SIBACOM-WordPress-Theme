<?php
/**
 * SIBACOM Info & Meta Bar Elementor Widget
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class SIBACOM_Info_Widget extends Widget_Base {

    public function get_name() {
        return 'sibacom_info';
    }

    public function get_title() {
        return esc_html__('SIBACOM Event Information Cards', 'sibacom-manager');
    }

    public function get_icon() {
        return 'eicon-info-box';
    }

    public function get_categories() {
        return array('sibacom-elements');
    }

    protected function register_controls() {
        // CONTENT TAB
        $this->start_controls_section(
            'section_content',
            array(
                'label' => esc_html__('Event Information Cards', 'sibacom-manager'),
            )
        );

        $this->add_control(
            'use_custom_values',
            array(
                'label'        => esc_html__('Custom Values Override', 'sibacom-manager'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Custom', 'sibacom-manager'),
                'label_off'    => esc_html__('Default', 'sibacom-manager'),
                'return_value' => 'yes',
                'default'      => '',
                'description'  => esc_html__('Enable to manually override values here in Elementor instead of WordPress settings.', 'sibacom-manager'),
            )
        );

        // Card 1
        $this->add_control(
            'card1_heading',
            array(
                'label'     => esc_html__('1. Event Dates Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card1_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Event Dates',
            )
        );
        $this->add_control(
            'card1_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Nov 30 – Dec 02, 2026',
            )
        );
        $this->add_control(
            'card1_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '1-Day National Summit',
            )
        );

        // Card 2
        $this->add_control(
            'card2_heading',
            array(
                'label'     => esc_html__('2. Event Venue Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card2_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Event Venue',
            )
        );
        $this->add_control(
            'card2_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Academic Block-III',
            )
        );
        $this->add_control(
            'card2_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Sukkur IBA University',
            )
        );

        // Card 3
        $this->add_control(
            'card3_heading',
            array(
                'label'     => esc_html__('3. Registration Deadline Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card3_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Registration Deadline',
            )
        );
        $this->add_control(
            'card3_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Nov 15, 2026',
            )
        );
        $this->add_control(
            'card3_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '11:59 PM PKT Strict Cutoff',
            )
        );

        // Card 4
        $this->add_control(
            'card4_heading',
            array(
                'label'     => esc_html__('4. Event Category Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card4_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Event Category',
            )
        );
        $this->add_control(
            'card4_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Tech Olympiad',
            )
        );
        $this->add_control(
            'card4_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '14+ Competitive Tracks',
            )
        );

        // Card 5
        $this->add_control(
            'card5_heading',
            array(
                'label'     => esc_html__('5. Participation Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card5_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Participation',
            )
        );
        $this->add_control(
            'card5_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '1,500+ Innovators',
            )
        );
        $this->add_control(
            'card5_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => '120+ Universities Nationwide',
            )
        );

        // Card 6
        $this->add_control(
            'card6_heading',
            array(
                'label'     => esc_html__('6. Registration Status Card', 'sibacom-manager'),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            )
        );
        $this->add_control(
            'card6_title',
            array(
                'label'   => esc_html__('Label', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Registration Status',
            )
        );
        $this->add_control(
            'card6_val',
            array(
                'label'   => esc_html__('Value', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Registration Open',
            )
        );
        $this->add_control(
            'card6_sub',
            array(
                'label'   => esc_html__('Subtitle', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Verified Delegate Portals',
            )
        );

        $this->end_controls_section();

        // STYLE TAB: Card Styling
        $this->start_controls_section(
            'section_style_cards',
            array(
                'label' => esc_html__('Cards Appearance', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'card_bg_color',
            array(
                'label'     => esc_html__('Card Background', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FFFFFF',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-info-card' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'card_box_shadow',
                'label'    => esc_html__('Card Shadow', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .sibacom-info-card',
            )
        );

        $this->add_control(
            'card_radius',
            array(
                'label'      => esc_html__('Border Radius', 'sibacom-manager'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array('px', 'rem'),
                'range'      => array('px' => array('min' => 0, 'max' => 40)),
                'default'    => array('unit' => 'px', 'size' => 20),
                'selectors'  => array(
                    '{{WRAPPER}} .sibacom-info-card' => 'border-radius: {{SIZE}}{{UNIT}};',
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ($settings['use_custom_values'] === 'yes') {
            ?>
            <div class="sibacom-event-info-cards-wrap">
                <div class="sibacom-info-cards-grid">
                    <!-- Card 1 -->
                    <div class="neu-card sibacom-info-card card-variant-dates">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #173F91; background: linear-gradient(135deg, rgba(23, 63, 145, 0.12) 0%, rgba(37, 99, 235, 0.06) 100%);">
                                <i class="fa-regular fa-calendar-days"></i>
                            </div>
                            <span class="sibacom-info-pill pill-blue">
                                <i class="fa-regular fa-calendar-check"></i> <?php esc_html_e('Official Dates', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card1_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card1_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card1_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-regular fa-calendar-days"></i>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="neu-card sibacom-info-card card-variant-venue">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #079B58; background: linear-gradient(135deg, rgba(7, 155, 88, 0.12) 0%, rgba(16, 185, 129, 0.06) 100%);">
                                <i class="fa-solid fa-location-dot"></i>
                            </div>
                            <span class="sibacom-info-pill pill-green">
                                <i class="fa-solid fa-building-columns"></i> <?php esc_html_e('Main Campus', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card2_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card2_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card2_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-solid fa-location-dot"></i>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="neu-card sibacom-info-card card-variant-deadline">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #D97706; background: linear-gradient(135deg, rgba(217, 119, 6, 0.12) 0%, rgba(245, 158, 11, 0.06) 100%);">
                                <i class="fa-solid fa-hourglass-half"></i>
                            </div>
                            <span class="sibacom-info-pill pill-amber">
                                <i class="fa-solid fa-hourglass-half"></i> <?php esc_html_e('Strict Cutoff', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card3_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card3_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card3_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-solid fa-hourglass-half"></i>
                        </div>
                    </div>

                    <!-- Card 4 -->
                    <div class="neu-card sibacom-info-card card-variant-category">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #102E68; background: linear-gradient(135deg, rgba(16, 46, 104, 0.12) 0%, rgba(67, 56, 202, 0.06) 100%);">
                                <i class="fa-solid fa-microchip"></i>
                            </div>
                            <span class="sibacom-info-pill pill-navy">
                                <i class="fa-solid fa-layer-group"></i> <?php esc_html_e('14+ Tracks', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card4_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card4_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card4_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-solid fa-microchip"></i>
                        </div>
                    </div>

                    <!-- Card 5 -->
                    <div class="neu-card sibacom-info-card card-variant-participation">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #1D4ED8; background: linear-gradient(135deg, rgba(29, 78, 216, 0.12) 0%, rgba(2, 132, 199, 0.06) 100%);">
                                <i class="fa-solid fa-users"></i>
                            </div>
                            <span class="sibacom-info-pill pill-cyan">
                                <i class="fa-solid fa-globe"></i> <?php esc_html_e('Nationwide', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card5_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card5_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card5_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-solid fa-users"></i>
                        </div>
                    </div>

                    <!-- Card 6 -->
                    <div class="neu-card sibacom-info-card card-variant-status">
                        <div class="sibacom-info-card-header">
                            <div class="sibacom-info-icon-badge" style="color: #079B58; background: linear-gradient(135deg, rgba(7, 155, 88, 0.14) 0%, rgba(5, 150, 105, 0.06) 100%);">
                                <span class="pulse-dot-live"></span>
                            </div>
                            <span class="sibacom-info-pill pill-live">
                                <span class="pulse-dot-live" style="width:6px; height:6px;"></span> <?php esc_html_e('Live Now', 'sibacom-manager'); ?>
                            </span>
                        </div>
                        <div class="sibacom-info-card-body">
                            <span class="sibacom-info-label"><?php echo esc_html($settings['card6_title']); ?></span>
                            <h4 class="font-display sibacom-info-val"><?php echo esc_html($settings['card6_val']); ?></h4>
                            <span class="sibacom-info-sub"><?php echo esc_html($settings['card6_sub']); ?></span>
                        </div>
                        <div class="sibacom-info-watermark" aria-hidden="true">
                            <i class="fa-solid fa-circle-check"></i>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        } else {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_info(array());
            }
        }
    }
}
