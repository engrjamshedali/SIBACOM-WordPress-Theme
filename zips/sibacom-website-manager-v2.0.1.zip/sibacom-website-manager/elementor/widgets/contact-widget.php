<?php
/**
 * SIBACOM Contact Details Elementor Widget
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class SIBACOM_Contact_Widget extends Widget_Base {

    public function get_name() {
        return 'sibacom_contact';
    }

    public function get_title() {
        return esc_html__('SIBACOM Contact Cards', 'sibacom-manager');
    }

    public function get_icon() {
        return 'eicon-envelope';
    }

    public function get_categories() {
        return array('sibacom-elements');
    }

    protected function register_controls() {
        // CONTENT TAB
        $this->start_controls_section(
            'section_content',
            array(
                'label' => esc_html__('Contact Information Cards', 'sibacom-manager'),
            )
        );

        $this->add_control(
            'use_custom',
            array(
                'label'        => esc_html__('Use Custom Overrides', 'sibacom-manager'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'sibacom-manager'),
                'label_off'    => esc_html__('No', 'sibacom-manager'),
                'return_value' => 'yes',
                'default'      => '',
            )
        );

        $this->add_control(
            'address',
            array(
                'label'       => esc_html__('Venue Address', 'sibacom-manager'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => get_option('sibacom_contact_address', 'Sukkur IBA University, Airport Road, Sukkur, Sindh, Pakistan'),
                'condition'   => array('use_custom' => 'yes'),
            )
        );

        $this->add_control(
            'email',
            array(
                'label'       => esc_html__('Official Email', 'sibacom-manager'),
                'type'        => Controls_Manager::TEXT,
                'default'     => get_option('sibacom_contact_email', 'sibacom@iba-suk.edu.pk'),
                'condition'   => array('use_custom' => 'yes'),
            )
        );

        $this->add_control(
            'phone',
            array(
                'label'       => esc_html__('Contact Phone', 'sibacom-manager'),
                'type'        => Controls_Manager::TEXT,
                'default'     => get_option('sibacom_contact_phone', '+92 71 5644000'),
                'condition'   => array('use_custom' => 'yes'),
            )
        );

        $this->end_controls_section();

        // STYLE TAB
        $this->start_controls_section(
            'section_style_contact',
            array(
                'label' => esc_html__('Cards Appearance', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'card_bg',
            array(
                'label'     => esc_html__('Card Background', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FFFFFF',
                'selectors' => array(
                    '{{WRAPPER}} .neu-card' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'card_shadow',
                'label'    => esc_html__('Card Shadow', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .neu-card',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ($settings['use_custom'] === 'yes') {
            $address = $settings['address'];
            $email   = $settings['email'];
            $phone   = $settings['phone'];
            ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; max-width: 1040px; margin: 0 auto;">
                <div class="neu-card">
                    <div class="sibacom-highlight-icon"><i class="fa-solid fa-location-dot"></i></div>
                    <h3 class="font-display" style="font-size: 1.25rem; margin-bottom: 0.5rem;"><?php esc_html_e('Event Venue Location', 'sibacom-manager'); ?></h3>
                    <p style="font-size: 0.95rem; margin-bottom: 1rem; color: var(--sibacom-text-secondary);"><?php echo esc_html($address); ?></p>
                    <span style="font-size: 0.82rem; font-weight: 600; color: var(--sibacom-techgreen);">
                        <?php esc_html_e('Accessible via Sukkur Airport & M-5 Motorway', 'sibacom-manager'); ?>
                    </span>
                </div>

                <div class="neu-card">
                    <div class="sibacom-highlight-icon"><i class="fa-solid fa-envelope"></i></div>
                    <h3 class="font-display" style="font-size: 1.25rem; margin-bottom: 0.5rem;"><?php esc_html_e('Electronic Mail', 'sibacom-manager'); ?></h3>
                    <p style="font-size: 0.95rem; margin-bottom: 1rem;">
                        <a href="mailto:<?php echo esc_attr($email); ?>" style="font-weight: 600; color: var(--sibacom-primary);"><?php echo esc_html($email); ?></a>
                    </p>
                    <span style="font-size: 0.82rem; font-weight: 600; color: var(--sibacom-techgreen);">
                        <?php esc_html_e('Official Secretariat Helpdesk', 'sibacom-manager'); ?>
                    </span>
                </div>

                <div class="neu-card">
                    <div class="sibacom-highlight-icon"><i class="fa-solid fa-phone"></i></div>
                    <h3 class="font-display" style="font-size: 1.25rem; margin-bottom: 0.5rem;"><?php esc_html_e('Telephone & Helpdesk', 'sibacom-manager'); ?></h3>
                    <p style="font-size: 0.95rem; margin-bottom: 1rem;">
                        <a href="tel:<?php echo esc_attr($phone); ?>" style="font-weight: 600; color: var(--sibacom-primary);"><?php echo esc_html($phone); ?></a>
                    </p>
                    <span style="font-size: 0.82rem; font-weight: 600; color: var(--sibacom-techgreen);">
                        <?php esc_html_e('Mon – Fri, 09:00 AM – 05:00 PM PKT', 'sibacom-manager'); ?>
                    </span>
                </div>
            </div>
            <?php
        } else {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_contact(array());
            }
        }
    }
}
