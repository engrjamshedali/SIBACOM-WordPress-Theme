<?php
/**
 * SIBACOM Organizers Elementor Widget
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class SIBACOM_Organizers_Widget extends Widget_Base {

    public function get_name() {
        return 'sibacom_organizers';
    }

    public function get_title() {
        return esc_html__('SIBACOM Organizers Grid', 'sibacom-manager');
    }

    public function get_icon() {
        return 'eicon-site-identity';
    }

    public function get_categories() {
        return array('sibacom-elements');
    }

    protected function register_controls() {
        // CONTENT TAB
        $this->start_controls_section(
            'section_content',
            array(
                'label' => esc_html__('Organizers Configuration', 'sibacom-manager'),
            )
        );

        $this->add_control(
            'data_mode',
            array(
                'label'   => esc_html__('Display Structure', 'sibacom-manager'),
                'type'    => Controls_Manager::SELECT,
                'default' => 'dynamic',
                'options' => array(
                    'dynamic'       => esc_html__('Complete Hierarchy (Joint Organizers + Academic Partners + Host)', 'sibacom-manager'),
                    'joint_only'    => esc_html__('Joint Primary Organizers Only (CSE & EE Societies)', 'sibacom-manager'),
                    'academic_only' => esc_html__('Academic Partners Only (CSE & EE Departments)', 'sibacom-manager'),
                    'manual'        => esc_html__('Custom Organizing Partners (Visual Repeater)', 'sibacom-manager'),
                ),
            )
        );

        $this->add_control(
            'joint_sec_title',
            array(
                'label'     => esc_html__('Joint Organizers Title', 'sibacom-manager'),
                'type'      => Controls_Manager::TEXT,
                'default'   => 'JOINTLY ORGANIZED BY',
                'condition' => array(
                    'data_mode' => array('dynamic', 'joint_only'),
                ),
            )
        );

        $this->add_control(
            'joint_sec_subtitle',
            array(
                'label'     => esc_html__('Joint Organizers Subtitle', 'sibacom-manager'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => 'Bringing together the Computer Systems Engineering and Electrical Engineering communities.',
                'condition' => array(
                    'data_mode' => array('dynamic', 'joint_only'),
                ),
            )
        );

        $this->add_control(
            'academic_sec_title',
            array(
                'label'     => esc_html__('Academic Partners Title', 'sibacom-manager'),
                'type'      => Controls_Manager::TEXT,
                'default'   => 'ACADEMIC PARTNERS',
                'condition' => array(
                    'data_mode' => array('dynamic', 'academic_only'),
                ),
            )
        );

        $this->add_control(
            'academic_sec_subtitle',
            array(
                'label'     => esc_html__('Academic Partners Subtitle', 'sibacom-manager'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => 'Supporting academic departments providing faculty advisement, research laboratory facilities, and international judging standards.',
                'condition' => array(
                    'data_mode' => array('dynamic', 'academic_only'),
                ),
            )
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'org_badge',
            array(
                'label'   => esc_html__('Role Badge', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Organizing Body',
            )
        );

        $repeater->add_control(
            'org_title',
            array(
                'label'   => esc_html__('Organization Title', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'CSE Society – Technology Circuit',
            )
        );

        $repeater->add_control(
            'org_desc',
            array(
                'label'   => esc_html__('Description', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => 'The premier student engineering society of the Department of Computer Systems Engineering.',
            )
        );

        $repeater->add_control(
            'org_logo',
            array(
                'label'   => esc_html__('Logo Image', 'sibacom-manager'),
                'type'    => Controls_Manager::MEDIA,
            )
        );

        $repeater->add_control(
            'org_footer_text',
            array(
                'label'   => esc_html__('Footer Tag', 'sibacom-manager'),
                'type'    => Controls_Manager::TEXT,
                'default' => 'Executive Secretariat Lead',
            )
        );

        $this->add_control(
            'manual_orgs',
            array(
                'label'       => esc_html__('Custom Partners & Committees', 'sibacom-manager'),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ org_title }}}',
                'condition'   => array(
                    'data_mode' => 'manual',
                ),
            )
        );

        $this->end_controls_section();

        // STYLE TAB
        $this->start_controls_section(
            'section_style_org',
            array(
                'label' => esc_html__('Cards Appearance', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'card_bg',
            array(
                'label'     => esc_html__('Card Background', 'sibacom-manager'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#FFFFFF',
                'selectors' => array(
                    '{{WRAPPER}} .sibacom-org-card' => 'background-color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => 'title_typography',
                'label'    => esc_html__('Title Typography', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .sibacom-org-card h3',
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'     => 'card_shadow',
                'label'    => esc_html__('Card Shadow', 'sibacom-manager'),
                'selector' => '{{WRAPPER}} .sibacom-org-card',
            )
        );

        $this->add_control(
            'logo_max_height',
            array(
                'label'      => esc_html__('Logo Maximum Height', 'sibacom-manager'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array('px'),
                'range'      => array(
                    'px' => array(
                        'min' => 40,
                        'max' => 140,
                        'step' => 2,
                    ),
                ),
                'default'    => array(
                    'unit' => 'px',
                    'size' => 75,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .sibacom-org-logo-wrap img' => 'height: {{SIZE}}{{UNIT}} !important; max-height: {{SIZE}}{{UNIT}} !important;',
                    '{{WRAPPER}} .sibacom-org-logo-wrap .ee-society-insignia' => 'height: {{SIZE}}{{UNIT}} !important; max-height: {{SIZE}}{{UNIT}} !important;',
                    '{{WRAPPER}} .sibacom-org-logo-wrap .ee-dept-insignia' => 'height: {{SIZE}}{{UNIT}} !important; max-height: {{SIZE}}{{UNIT}} !important;',
                ),
            )
        );

        $this->end_controls_section();

        // Style Tab: Circuit Connector & PCB Accents
        $this->start_controls_section(
            'section_style_org_circuits',
            array(
                'label' => esc_html__('Circuit Connector & PCB Accents', 'sibacom-manager'),
                'tab'   => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'enable_org_circuits',
            array(
                'label'        => esc_html__('Enable Circuit Styling & Connectors', 'sibacom-manager'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Yes', 'sibacom-manager'),
                'label_off'    => esc_html__('No', 'sibacom-manager'),
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $mode     = !empty($settings['data_mode']) ? $settings['data_mode'] : 'dynamic';

        if ($mode === 'joint_only') {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_joint_organizers(array());
            }
        } elseif ($mode === 'academic_only') {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_academic_partners(array());
            }
        } elseif ($mode === 'dynamic') {
            if (class_exists('SIBACOM_Shortcodes')) {
                echo SIBACOM_Shortcodes::render_organizers(array());
            }
        } else {
            $orgs = !empty($settings['manual_orgs']) ? $settings['manual_orgs'] : array();
            ?>
            <div class="sibacom-organizers-grid">
                <?php foreach ($orgs as $o) : 
                    $logo_url = !empty($o['org_logo']['url']) ? $o['org_logo']['url'] : '';
                    ?>
                    <div class="sibacom-org-card neu-card sibacom-card-circuit">
                        <?php if ((!isset($settings['enable_org_circuits']) || $settings['enable_org_circuits'] !== 'no') && function_exists('sibacom_the_circuit_corner')) : ?>
                            <?php sibacom_the_circuit_corner('tl'); ?>
                            <?php sibacom_the_circuit_corner('br'); ?>
                        <?php endif; ?>
                        <div>
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                                <?php if (!empty($o['org_badge'])) : ?>
                                    <span style="font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: var(--sibacom-primary); background: rgba(23,63,145,0.1); padding: 0.25rem 0.75rem; border-radius: var(--radius-full);">
                                        <?php echo esc_html($o['org_badge']); ?>
                                    </span>
                                <?php endif; ?>
                                <i class="fa-solid fa-award" style="color: var(--sibacom-primary); font-size: 1.25rem;"></i>
                            </div>
                            <?php if (!empty($logo_url)) : ?>
                                <div class="sibacom-org-logo-wrap">
                                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($o['org_title']); ?>" width="200" height="75" loading="lazy" decoding="async" style="max-height: 75px; width: auto; object-fit: contain;">
                                </div>
                            <?php endif; ?>
                            <h3 class="font-display" style="font-size: 1.35rem; margin-bottom: 0.75rem; color: var(--sibacom-text-primary);">
                                <?php echo esc_html($o['org_title']); ?>
                            </h3>
                            <p style="font-size: 0.92rem; color: var(--sibacom-text-secondary); line-height: 1.65;">
                                <?php echo esc_html($o['org_desc']); ?>
                            </p>
                        </div>
                        <?php if (!empty($o['org_footer_text'])) : ?>
                            <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--sibacom-border);">
                                <span style="font-size: 0.8rem; font-weight: 600; color: var(--sibacom-techgreen);">
                                    <i class="fa-solid fa-circle-check" style="margin-right: 0.35rem;"></i>
                                    <?php echo esc_html($o['org_footer_text']); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
        }
    }
                                    <i class="fa-solid fa-circle-check" style="margin-right: 0.35rem;"></i>
                                    <?php echo esc_html($o['org_footer_text']); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
        }
    }
}
