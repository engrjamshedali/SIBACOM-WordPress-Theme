/**
 * SIBACOM Website Manager - Frontend Widget JS
 */
jQuery(document).ready(function ($) {
  // Any widget-specific event bindings if required
});

