<?php
/**
 * SIBACOM General Settings View
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap sibacom-admin-wrap">
    <div class="sibacom-admin-header">
        <div>
            <h1><?php esc_html_e('General Website Settings', 'sibacom-manager'); ?></h1>
            <p><?php esc_html_e('Manage core event information, institutional logos, contact credentials, and copyright text.', 'sibacom-manager'); ?></p>
        </div>
    </div>

    <form method="post" action="options.php">
        <?php
        settings_fields('sibacom_settings_group');
        ?>

        <!-- 1. Core Event Details -->
        <div class="sibacom-panel-card">
            <h2><?php esc_html_e('Event Identification', 'sibacom-manager'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Titles, dates, and venue coordinates.', 'sibacom-manager'); ?></p>

            <div class="sibacom-form-row">
                <label for="sibacom_event_name"><?php esc_html_e('Official Event Name (Must be SIBACOM):', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_event_name" name="sibacom_event_name" value="<?php echo esc_attr(get_option('sibacom_event_name', 'SIBACOM')); ?>" required />
            </div>

            <div class="sibacom-form-row">
                <label for="sibacom_event_tagline"><?php esc_html_e('Event Tagline / Subtitle:', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_event_tagline" name="sibacom_event_tagline" value="<?php echo esc_attr(get_option('sibacom_event_tagline', 'Sukkur IBA Annual Mega Olympiad & Innovation Competitions')); ?>" />
            </div>

            <div class="sibacom-form-row">
                <label for="sibacom_event_description"><?php esc_html_e('Event Description Summary:', 'sibacom-manager'); ?></label>
                <textarea id="sibacom_event_description" name="sibacom_event_description" rows="3"><?php echo esc_textarea(get_option('sibacom_event_description')); ?></textarea>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:650px;">
                <div class="sibacom-form-row">
                    <label for="sibacom_event_dates"><?php esc_html_e('Event Date Range Display:', 'sibacom-manager'); ?></label>
                    <input type="text" id="sibacom_event_dates" name="sibacom_event_dates" value="<?php echo esc_attr(get_option('sibacom_event_dates', 'November 30 – December 02, 2026')); ?>" />
                </div>

                <div class="sibacom-form-row">
                    <label for="sibacom_event_venue"><?php esc_html_e('Campus Venue Name:', 'sibacom-manager'); ?></label>
                    <input type="text" id="sibacom_event_venue" name="sibacom_event_venue" value="<?php echo esc_attr(get_option('sibacom_event_venue', 'Sukkur IBA University – Main Campus')); ?>" />
                </div>
            </div>

            <div class="sibacom-form-row">
                <label for="sibacom_event_location"><?php esc_html_e('Geographic Address / Location:', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_event_location" name="sibacom_event_location" value="<?php echo esc_attr(get_option('sibacom_event_location', 'Airport Road, Sukkur, Sindh, Pakistan')); ?>" />
            </div>
        </div>

        <!-- 2. Official Branding Logos (Hierarchical Organization) -->
        <div class="sibacom-panel-card">
            <h2><?php esc_html_e('Official Branding & Institutional Logos', 'sibacom-manager'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Manage verified official logos for the overarching institution, joint organizing societies, and academic partners.', 'sibacom-manager'); ?></p>

            <!-- A. Institutional Identity -->
            <h3 style="font-size: 1.1rem; color: #173F91; margin: 1.5rem 0 0.75rem 0; padding-bottom: 0.35rem; border-bottom: 1px solid #E2E8F0;">
                <?php esc_html_e('A. Overarching Institutional Identity', 'sibacom-manager'); ?>
            </h3>
            
            <div class="sibacom-form-row">
                <label><?php esc_html_e('Sukkur IBA University Official Logo:', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_university_logo_url" name="sibacom_university_logo_url" value="<?php echo esc_attr(get_option('sibacom_university_logo_url')); ?>" placeholder="Default bundled logo will be used if empty" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_university_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
            </div>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('Sukkur IBA University White/Monochrome Logo (For Footer/Dark BG):', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_university_logo_white_url" name="sibacom_university_logo_white_url" value="<?php echo esc_attr(get_option('sibacom_university_logo_white_url')); ?>" placeholder="Default bundled white logo will be used if empty" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_university_logo_white_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
            </div>

            <!-- B. Joint Primary Organizers -->
            <h3 style="font-size: 1.1rem; color: #173F91; margin: 1.75rem 0 0.75rem 0; padding-bottom: 0.35rem; border-bottom: 1px solid #E2E8F0;">
                <?php esc_html_e('B. Joint Primary Organizers (Equal Prominence)', 'sibacom-manager'); ?>
            </h3>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('CSE Society Official Logo (Joint Primary Organizer):', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_cse_society_logo_url" name="sibacom_cse_society_logo_url" value="<?php echo esc_attr(get_option('sibacom_cse_society_logo_url', get_option('sibacom_society_logo_url'))); ?>" placeholder="Default bundled CSE Society logo will be used if empty" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_cse_society_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
            </div>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('EE Society Official Logo (Joint Primary Organizer):', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_ee_society_logo_url" name="sibacom_ee_society_logo_url" value="<?php echo esc_attr(get_option('sibacom_ee_society_logo_url')); ?>" placeholder="Upload official EE Society logo from Media Library" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_ee_society_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
                <p class="description" style="color: #64748B; font-size: 0.85rem; margin-top: 4px;">
                    <?php esc_html_e('Upload the original official EE Society logo. Proportions and dimensions are automatically aligned with the CSE Society logo to preserve 100% equal prominence.', 'sibacom-manager'); ?>
                </p>
            </div>

            <!-- C. Supporting Academic Partners -->
            <h3 style="font-size: 1.1rem; color: #102E68; margin: 1.75rem 0 0.75rem 0; padding-bottom: 0.35rem; border-bottom: 1px solid #E2E8F0;">
                <?php esc_html_e('C. Academic Partners (Departmental Affiliations)', 'sibacom-manager'); ?>
            </h3>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('Department of Computer Systems Engineering Logo:', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_cse_dept_logo_url" name="sibacom_cse_dept_logo_url" value="<?php echo esc_attr(get_option('sibacom_cse_dept_logo_url', get_option('sibacom_dept_logo_url'))); ?>" placeholder="Default bundled CSE Dept logo will be used if empty" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_cse_dept_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
            </div>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('Department of Electrical Engineering Logo:', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_ee_dept_logo_url" name="sibacom_ee_dept_logo_url" value="<?php echo esc_attr(get_option('sibacom_ee_dept_logo_url')); ?>" placeholder="Upload official EE Department logo from Media Library" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_ee_dept_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
                <p class="description" style="color: #64748B; font-size: 0.85rem; margin-top: 4px;">
                    <?php esc_html_e('Upload the official Department of Electrical Engineering logo for display in the Academic Partners section.', 'sibacom-manager'); ?>
                </p>
            </div>

            <!-- D. Student Governance -->
            <h3 style="font-size: 1.1rem; color: #64748B; margin: 1.75rem 0 0.75rem 0; padding-bottom: 0.35rem; border-bottom: 1px solid #E2E8F0;">
                <?php esc_html_e('D. Student Council (Coordination)', 'sibacom-manager'); ?>
            </h3>

            <div class="sibacom-form-row">
                <label><?php esc_html_e('SISC (Sukkur IBA Student Council) Logo:', 'sibacom-manager'); ?></label>
                <div class="sibacom-media-row">
                    <input type="text" id="sibacom_sisc_logo_url" name="sibacom_sisc_logo_url" value="<?php echo esc_attr(get_option('sibacom_sisc_logo_url')); ?>" placeholder="Default bundled logo will be used if empty" />
                    <button type="button" class="button sibacom-media-upload-btn" data-target="#sibacom_sisc_logo_url"><?php esc_html_e('Choose from Media', 'sibacom-manager'); ?></button>
                </div>
            </div>
        </div>

        <!-- 3. Official Contact & Social Media -->
        <div class="sibacom-panel-card">
            <h2><?php esc_html_e('Official Secretariat Contact & Social Handles', 'sibacom-manager'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Contact channels shown in the header, footer, and contact section.', 'sibacom-manager'); ?></p>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:650px;">
                <div class="sibacom-form-row">
                    <label for="sibacom_contact_email"><?php esc_html_e('Support / Official Email:', 'sibacom-manager'); ?></label>
                    <input type="email" id="sibacom_contact_email" name="sibacom_contact_email" value="<?php echo esc_attr(get_option('sibacom_contact_email', 'sibacom@iba-suk.edu.pk')); ?>" />
                </div>

                <div class="sibacom-form-row">
                    <label for="sibacom_contact_phone"><?php esc_html_e('Official Contact Phone:', 'sibacom-manager'); ?></label>
                    <input type="text" id="sibacom_contact_phone" name="sibacom_contact_phone" value="<?php echo esc_attr(get_option('sibacom_contact_phone', '+92 71 5644000')); ?>" />
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:650px;">
                <div class="sibacom-form-row">
                    <label for="sibacom_social_linkedin"><?php esc_html_e('LinkedIn URL:', 'sibacom-manager'); ?></label>
                    <input type="url" id="sibacom_social_linkedin" name="sibacom_social_linkedin" value="<?php echo esc_attr(get_option('sibacom_social_linkedin', 'https://www.linkedin.com/school/sukkur-iba-university/')); ?>" />
                </div>

                <div class="sibacom-form-row">
                    <label for="sibacom_social_twitter"><?php esc_html_e('Twitter / X URL:', 'sibacom-manager'); ?></label>
                    <input type="url" id="sibacom_social_twitter" name="sibacom_social_twitter" value="<?php echo esc_attr(get_option('sibacom_social_twitter', 'https://twitter.com')); ?>" />
                </div>
            </div>

            <div class="sibacom-form-row">
                <label for="sibacom_copyright_text"><?php esc_html_e('Copyright Line:', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_copyright_text" name="sibacom_copyright_text" value="<?php echo esc_attr(get_option('sibacom_copyright_text', '© 2026 SIBACOM – Sukkur IBA University. All Rights Reserved.')); ?>" />
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="submit" id="submit" class="button button-primary sibacom-btn-save" value="<?php esc_attr_e('Save General Settings', 'sibacom-manager'); ?>" />
        </p>
    </form>
</div>
<?php

