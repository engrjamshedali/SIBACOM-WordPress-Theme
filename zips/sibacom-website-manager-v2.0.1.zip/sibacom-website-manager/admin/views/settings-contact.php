<?php
/**
 * SIBACOM Contact Settings View
 *
 * @package SIBACOM_Website_Manager
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap sibacom-admin-wrap">
    <div class="sibacom-admin-header">
        <div>
            <h1><?php esc_html_e('Contact Information Manager', 'sibacom-manager'); ?></h1>
            <p><?php esc_html_e('Configure official secretariat helpdesk email, phone, university address, and directions.', 'sibacom-manager'); ?></p>
        </div>
    </div>

    <form method="post" action="options.php">
        <?php settings_fields('sibacom_settings_group'); ?>

        <div class="sibacom-panel-card">
            <h2><?php esc_html_e('Contact Section Intro', 'sibacom-manager'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Header text shown in the contact section of the website.', 'sibacom-manager'); ?></p>

            <div class="sibacom-form-row">
                <label for="sibacom_contact_heading"><?php esc_html_e('Section Heading:', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_contact_heading" name="sibacom_contact_heading" value="<?php echo esc_attr(get_option('sibacom_contact_heading', 'Get in Touch with SIBACOM Committee')); ?>" />
            </div>

            <div class="sibacom-form-row">
                <label for="sibacom_contact_description"><?php esc_html_e('Section Description:', 'sibacom-manager'); ?></label>
                <textarea id="sibacom_contact_description" name="sibacom_contact_description" rows="3"><?php echo esc_textarea(get_option('sibacom_contact_description')); ?></textarea>
            </div>
        </div>

        <div class="sibacom-panel-card">
            <h2><?php esc_html_e('Secretariat Details', 'sibacom-manager'); ?></h2>
            <p class="subtitle"><?php esc_html_e('Direct physical and electronic coordinates.', 'sibacom-manager'); ?></p>

            <div class="sibacom-form-row">
                <label for="sibacom_contact_address"><?php esc_html_e('Physical Campus Address:', 'sibacom-manager'); ?></label>
                <input type="text" id="sibacom_contact_address" name="sibacom_contact_address" value="<?php echo esc_attr(get_option('sibacom_contact_address', 'Sukkur IBA University, Airport Road, Sukkur, Sindh, Pakistan')); ?>" />
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:650px;">
                <div class="sibacom-form-row">
                    <label for="sibacom_contact_email"><?php esc_html_e('Official Secretariat Email:', 'sibacom-manager'); ?></label>
                    <input type="email" id="sibacom_contact_email" name="sibacom_contact_email" value="<?php echo esc_attr(get_option('sibacom_contact_email', 'sibacom@iba-suk.edu.pk')); ?>" />
                </div>

                <div class="sibacom-form-row">
                    <label for="sibacom_contact_phone"><?php esc_html_e('Telephone & WhatsApp Line:', 'sibacom-manager'); ?></label>
                    <input type="text" id="sibacom_contact_phone" name="sibacom_contact_phone" value="<?php echo esc_attr(get_option('sibacom_contact_phone', '+92 71 5644000')); ?>" />
                </div>
            </div>
        </div>

        <p class="submit">
            <input type="submit" name="submit" class="button button-primary sibacom-btn-save" value="<?php esc_attr_e('Save Contact Information', 'sibacom-manager'); ?>" />
        </p>
    </form>
</div>
<?php

